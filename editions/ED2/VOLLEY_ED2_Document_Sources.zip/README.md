# VOLLEY academic edition ED2 — document sources

27 October 2026. This package rebuilds the 57-page academic report and 17-slide presentation from their versioned sources, local figures and captured numerical inputs. The presentation retains the 15-minute, two-speaker route.

Identical assets shared by the report and presentation are stored once under `shared_assets/`. `ASSET_MAP.json` records their original paths and SHA-256 identities. Restore those paths before building:

```sh
python3 materialize_assets.py --verify-only
python3 materialize_assets.py
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-documents.txt
.venv/bin/python current/academic/build_report.py
.venv/bin/python cache_docx_indexes.py
.venv/bin/python current/presentation/build_presentation.py
soffice --headless --convert-to pdf --outdir current/presentation current/presentation/VOLLEY_BTech_Presentation.pptx
```

Reference environment: Python 3.12; Pandoc 3.1.11.1; XeTeX 0.999996 from TeX Live 2025/dev; LibreOffice 25.2.3.2. Pandoc 3.1.3 or later and TeX Live 2022 or later with XeLaTeX are supported build prerequisites. Install Liberation Serif, Liberation Sans and DejaVu Sans Mono fonts. LaTeX needs the Pandoc default-template packages plus `setspace`, `titlesec`, `caption`, `chngcntr` and `pgf/TikZ`.

Python package versions are pinned in `requirements-documents.txt`. No internet account, private checkout or native engineering solver is required for the document builds. Outputs are written beside their builders. Build timestamps, fonts and tool versions may change binary identities; `BUILD_REFERENCE.json` pins the distributed ED2 document bytes. Refresh native Word fields after any Word repagination before printing a DOCX-derived edition.

The captured numerical data and source pins identify the report's computational evidence. Engineering-model regeneration uses the separately published ACR1 engineering packages and matched static supplement. This archive contains the genuine figure PDFs as source assets and omits generated report/deck binaries, caches and backups.
