"""Supply valid refreshable Word fields with visible PDF-reference index caches.

Cached page references follow the verified companion PDF. Word may repaginate;
refresh its fields after any source/font/layout change before printing the DOCX.
"""
from pathlib import Path
import fitz,re,json,importlib.util
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt,Mm
ROOT=Path(__file__).resolve().parent;A=ROOT/'current/academic'
PDF=fitz.open(A/'GEN5_FINAL_YEAR_REPORT.pdf');document=Document(A/'GEN5_FINAL_YEAR_REPORT.docx')
# Repair the historical nested field representation if present in the build.
roots=[document.element]+[section.footer._element for section in document.sections]
for xmlroot in roots:
 for child in list(xmlroot.xpath('.//w:r/w:fldSimple')):
  run=child.getparent();parent=run.getparent();pos=parent.index(run);run.remove(child);parent.insert(pos,child)
  if len(run)==0:parent.remove(run)
def folio(page):
 text=page.get_textbox(fitz.Rect(0,page.rect.height-50,page.rect.width,page.rect.height)).strip()
 matches=re.findall(r'(?m)^\s*([0-9]+|[ivxlcdm]+)\s*$',text)
 if not matches:raise ValueError('Missing printed folio '+str(page.number+1))
 return matches[-1]
folio_map={i+1:folio(p) for i,p in enumerate(PDF) if i>0}
toc=[(level,title,folio_map[physical]) for level,title,physical in PDF.get_toc()]
filtertext=(A/'layout/evidence-links.lua').read_text()
def titles(name):
 return json.loads('['+re.search('local '+name+r'=\{(.*?)\}',filtertext,re.S).group(1)+']')
figure_names=titles('short_figures');table_names=titles('short_tables')
def caption_entries(kind,names):
 found={}
 for page in PDF:
  for match in re.finditer(r'\b'+kind+r'\s+(\d+)\s*:',page.get_text()):
   index=int(match.group(1));found.setdefault(index,folio_map[page.number+1])
 assert len(found)==len(names),(kind,len(found),len(names))
 return [(1,kind+' '+str(i+1)+'  '+name,found[i+1]) for i,name in enumerate(names)]
figures=caption_entries('Figure',figure_names);tables=caption_entries('Table',table_names)
cache_records=[]
for field in list(document.element.xpath('.//w:fldSimple')):
 instruction=field.get(qn('w:instr'),'')
 if not instruction.startswith('TOC'):continue
 entries=figures if '\\c "Figure"' in instruction else tables if '\\c "Table"' in instruction else toc
 paragraph=field.getparent();body=paragraph.getparent();position=body.index(paragraph)
 assert paragraph.tag==qn('w:p')
 # A complex field can contain several native paragraphs in its cached result.
 created=[]
 for i,(level,title,page) in enumerate(entries):
  p=OxmlElement('w:p');props=OxmlElement('w:pPr');spacing=OxmlElement('w:spacing');spacing.set(qn('w:after'),'30');props.append(spacing)
  indent=OxmlElement('w:ind');indent.set(qn('w:left'),str((level-1)*240));props.append(indent)
  tabs=OxmlElement('w:tabs');tab=OxmlElement('w:tab');tab.set(qn('w:val'),'right');tab.set(qn('w:pos'),'8674');tab.set(qn('w:leader'),'dot');tabs.append(tab);props.append(tabs);p.append(props)
  if i==0:
   for typ in ['begin','instruction','separate']:
    run=OxmlElement('w:r')
    if typ=='instruction':el=OxmlElement('w:instrText');el.set(qn('xml:space'),'preserve');el.text=instruction
    else:el=OxmlElement('w:fldChar');el.set(qn('w:fldCharType'),typ)
    run.append(el);p.append(run)
  run=OxmlElement('w:r');text=OxmlElement('w:t');text.text=title;run.append(text);p.append(run)
  run=OxmlElement('w:r');run.append(OxmlElement('w:tab'));p.append(run)
  run=OxmlElement('w:r');text=OxmlElement('w:t');text.text=page;run.append(text);p.append(run)
  if i==len(entries)-1:
   run=OxmlElement('w:r');end=OxmlElement('w:fldChar');end.set(qn('w:fldCharType'),'end');run.append(end);p.append(run)
  created.append(p)
 for offset,p in enumerate(created):body.insert(position+offset,p)
 body.remove(paragraph)
 cache_records.append({'field':instruction,'cached_entries':len(entries),'page_reference_basis':'companion candidate PDF; refresh in Word after repagination'})
assert len(cache_records)==3
assert len(document.tables)==15
assert not document.element.xpath('.//w:r/w:fldSimple')
document.core_properties.subject='Private ED2 review candidate; refreshable Word indexes cached from companion PDF'
document.save(A/'GEN5_FINAL_YEAR_REPORT.docx')
(ROOT/'DOCX_INDEX_CACHE.json').write_text(json.dumps({'fields':cache_records,'native_tables':len(document.tables),'page_footer_field_present':any('PAGE' in (f.get(qn('w:instr')) or '') for section in document.sections for f in section.footer._element.xpath('.//w:fldSimple'))},indent=2)+'\n')
print('Cached visible native Word indexes',[(x['cached_entries']) for x in cache_records],'and retained15tables')
