#!/usr/bin/env python3
"""Verify and restore the original academic/presentation asset paths."""
from pathlib import Path
import argparse,hashlib,json,shutil
ROOT=Path(__file__).resolve().parent
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def local(relative):
 path=(ROOT/relative).resolve()
 if not path.is_relative_to(ROOT):raise ValueError('Asset path escapes source package: '+relative)
 return path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--verify-only',action='store_true');args=p.parse_args()
rows=json.loads((ROOT/'ASSET_MAP.json').read_text())['assets']
# Check the entire set before writing; never overwrite a different local file.
for row in rows:
 source=local(row['stored_path'])
 if not source.is_file() or sha(source)!=row['sha256']:raise SystemExit('FAIL: stored asset '+row['stored_path'])
 for relative in row['target_paths']:
  target=local(relative)
  if target.exists() and (not target.is_file() or sha(target)!=row['sha256']):raise SystemExit('FAIL: nonmatching destination '+relative)
written=retained=0
if not args.verify_only:
 for row in rows:
  source=local(row['stored_path'])
  for relative in row['target_paths']:
   target=local(relative)
   if target.exists():retained+=1;continue
   target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
   if sha(target)!=row['sha256']:raise SystemExit('FAIL: copied asset '+relative)
   written+=1
print(json.dumps({'verified_unique_assets':len(rows),'original_asset_paths':sum(len(row['target_paths']) for row in rows),'files_written':written,'matching_files_retained':retained,'mode':'verify_only' if args.verify_only else 'restore'},sort_keys=True))
