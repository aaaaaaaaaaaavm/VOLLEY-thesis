"""ED3 explanatory figures from unchanged ACR1 captured data and CAD render."""
from pathlib import Path
import json,hashlib,shutil,math,os,argparse
R=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(R/'.mplconfig'));os.environ.setdefault('XDG_CACHE_HOME',str(R/'.cache'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image,ImageDraw,ImageFont
parser=argparse.ArgumentParser();parser.add_argument('--source-root',type=Path,default=R/'current');args=parser.parse_args();C=args.source_root;A=C/'academic/assets';P=C/'presentation/assets'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();NAVY='#15364d';TEAL='#168c88';GREY='#9aa8b0';IVORY='#f3f2ed';INK='#243743'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':16,'axes.labelsize':17,'axes.titlesize':19,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','savefig.facecolor':'white'})
records=[]
def save(fig,name,sources,caption):
 fig.tight_layout();fig.savefig(A/(name+'.png'),dpi=180,bbox_inches='tight');fig.savefig(A/(name+'.pdf'),bbox_inches='tight');plt.close(fig);shutil.copyfile(A/(name+'.png'),P/(name+'.png'));records.append({'asset':name+'.png','sha256':sha(A/(name+'.png')),'sources':sources,'caption':caption})
# One custody path, with the holder stated at each transition.
W,H=1900,1350;im=Image.new('RGB',(W,H),IVORY);d=ImageDraw.Draw(im)
font=lambda n,b=False:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if b else '')+'.ttf',n)
d.text((100,60),'CAPTURE FIRST. THEN RELEASE THE PREVIOUS HOLDER.',font=font(47,True),fill=INK)
d.text((100,140),'The pallet stays with the reusable carrier during launch, arrest and return.',font=font(34),fill=INK)
rows=[('1','STORE','Cell keepers hold the payload.'),('2','FEED','Pusher feeds the lift-held pallet.'),('3','DOCK','Lift holds until carrier locks prove capture.'),('4','CLEAR','Lift withdraws; carrier holds the pallet.'),('5','RELEASE','Cams open; only the payload departs.'),('6','RECOVER','Motor arrests and returns carrier + pallet.')]
for i,(n,title,body) in enumerate(rows):
 y=245+i*172;d.rounded_rectangle((100,y,1800,y+132),radius=12,fill='white',outline='#cbd4d6',width=2);d.ellipse((130,y+25,212,y+107),fill=TEAL);d.text((171,y+66),n,font=font(43,True),fill='white',anchor='mm');d.text((250,y+27),title,font=font(37,True),fill=INK);d.text((570,y+30),body,font=font(42),fill=INK)
 if i<5:d.line((171,y+137,171,y+167),fill=TEAL,width=5);d.polygon([(160,y+155),(182,y+155),(171,y+169)],fill=TEAL)
im.save(A/'ED3_custody_flow.png');shutil.copyfile(A/'ED3_custody_flow.png',P/'ED3_custody_flow.png');records.append({'asset':'ED3_custody_flow.png','sha256':sha(A/'ED3_custody_flow.png'),'sources':['academic report custody sections; frozen captured/handoff/clear states'],'caption':'Schematic of the nominal custody sequence; no hardware geometry is invented.'})
# CAD annotations use the original orthographic camera, without geometry changes.
im=Image.open(A/'assembly_hero.png').convert('RGB');d=ImageDraw.Draw(im);v=json.loads((C/'academic/evidence/visuals/POLISH_PROVENANCE.json').read_text())['views'][0]['camera'];rx,ry,rz=v['rotation_euler_rad']
Rx=np.array([[1,0,0],[0,math.cos(rx),-math.sin(rx)],[0,math.sin(rx),math.cos(rx)]]);Ry=np.array([[math.cos(ry),0,math.sin(ry)],[0,1,0],[-math.sin(ry),0,math.cos(ry)]]);Rz=np.array([[math.cos(rz),-math.sin(rz),0],[math.sin(rz),math.cos(rz),0],[0,0,1]]);rot=Rz@Ry@Rx
width=v['orthographic_width_m'];height=width*im.height/im.width;loc=np.array(v['location_m']);targets=[('1',(.434,-.25,.70)),('2',(.75,.08,.55)),('3',(.434,0,.04)),('4',(1.60,0,0))]
for n,point in targets:
 q=rot.T@(np.array(point)-loc);x=(.5+q[0]/width)*im.width;y=(.5-q[1]/height)*im.height;rad=34;d.ellipse((x-rad,y-rad,x+rad,y+rad),fill=IVORY,outline=TEAL,width=5);d.text((x,y),n,font=font(44,True),fill=TEAL,anchor='mm')
im.save(A/'ED3_assembly_guide.png');shutil.copyfile(A/'ED3_assembly_guide.png',P/'ED3_assembly_guide.png');records.append({'asset':'ED3_assembly_guide.png','sha256':sha(A/'ED3_assembly_guide.png'),'sources':['assembly_hero.png','evidence/visuals/POLISH_PROVENANCE.json'],'source_render_sha256':sha(A/'assembly_hero.png'),'camera':v,'targets_m':targets,'caption':'Markers identify fixed storage, indexed lift, retained carrier/pallet and stator/guide track; original CAD render unchanged.'})
finite=json.loads((C/'analysis/FINITE_MOTOR.json').read_text());stations=finite['stations'];fig,ax=plt.subplots(figsize=(9,4.8));x=[p['displacement_m'] for p in stations]
ax.plot(x,[p['with_return_N_per_A'] for p in stations],color=TEAL,lw=3,label='Active bars + represented returns');ax.plot(x,[p['active_N_per_A'] for p in stations],color=NAVY,lw=3,label='Active bars');ax.set(xlabel='Carrier travel (m)',ylabel='Force coefficient (N / peak phase A)',ylim=(1.28,1.44));ax.grid(axis='y',alpha=.2);ax.legend(loc='center',fontsize=14,frameon=False);save(fig,'ED3_force',{'analysis/FINITE_MOTOR.json':sha(C/'analysis/FINITE_MOTOR.json')},'Captured finite-force coefficients; shared permanent-field assumptions.')
shot=json.loads((C/'analysis/COUPLED_SHOT.json').read_text());case=next(c for c in shot['cases'] if c['target_m_s']==3 and not c['adverse'] and c['inductance_H']==2e-5);trace=np.array([r[:3] for r in case['trace']],dtype=float);fig,ax=plt.subplots(figsize=(9,4.8));ax.plot(trace[:,1],trace[:,2],color=TEAL,lw=3);release=case['release'];ax.axvline(release['position_m'],color=NAVY,ls='--',lw=1.8);ax.annotate('Payload departs',xy=(release['position_m'],release['relative_speed_m_s']),xytext=(.78,3.35),arrowprops={'arrowstyle':'->','color':NAVY},fontsize=17,color=NAVY);ax.text(1.49,.45,'Carrier\narrest',ha='right',color=NAVY,fontsize=16);ax.set(xlabel='Carrier travel (m)',ylabel='Carrier speed relative to host (m/s)',xlim=(0,1.57),ylim=(0,3.65));ax.grid(axis='y',alpha=.2);save(fig,'ED3_shot_speed',{'analysis/COUPLED_SHOT.json':sha(C/'analysis/COUPLED_SHOT.json')},'Nominal 3 m/s, 20 microhenry captured production trace; speed is carrier-to-host, not inertial orbital delta-v.')
proof=C/'academic/evidence/ansys/ACR1_STATIC_CROSSCHECK.json';values=[.28598334973500683,.2852406354826581,.28639191411004894,.28758919214871803];fig,ax=plt.subplots(figsize=(9,4.8));bars=ax.bar(['CalculiX\nreference','ANSYS\nh5.5','ANSYS\nh4.5 primary','ANSYS\nh4.0'],values,color=[NAVY,GREY,TEAL,GREY],width=.60);ax.set(ylabel='Maximum paired closure (mm)',ylim=(0,.34));ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
for bar,value in zip(bars,values):ax.text(bar.get_x()+bar.get_width()/2,value+.007,f'{value:.6f}',ha='center',fontsize=14)
save(fig,'ED3_static_comparison',{'academic/evidence/ansys/ACR1_STATIC_CROSSCHECK.json':sha(proof)},'Matched bare-chassis loads/restraints; three meshes form sensitivity evidence, not a formal convergence bound.')
mission=json.loads((C/'mission/MISSION_COMPARISON.json').read_text());chosen=[]
for architecture in ['gen5','spring_pretrim']:
 candidates=[c for c in mission['cases'] if c['family']=='alternating_1_3' and c['architecture']==architecture and c['authority_results']['5.0']['feasible_in_declared_candidate']];assert candidates,architecture;chosen.append(min(candidates,key=lambda c:c['fuel_used_kg']))
fig,ax=plt.subplots(figsize=(9,4.8));bars=ax.bar(['VOLLEY\ncommanded release','Ideal ground\npretrim spring'],[c['fuel_used_kg'] for c in chosen],color=[NAVY,TEAL],width=.5);ax.set(ylabel='Host fuel used (kg)',ylim=(0,.34));ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
for bar,c in zip(bars,chosen):ax.text(bar.get_x()+bar.get_width()/2,c['fuel_used_kg']+.012,f"{c['fuel_used_kg']:.4f} kg",ha='center',fontsize=19,fontweight='bold')
save(fig,'ED3_mission_fuel',{'mission/MISSION_COMPARISON.json':sha(C/'mission/MISSION_COMPARISON.json'),'case_stems':[c['case_stem'] for c in chosen]},'Alternating 1/3 m/s target family, 5 N authority; selected lowest-fuel feasible tested policies.')
(R/'FIGURE_SOURCES.json').write_text(json.dumps({'edition':'VOLLEY-G5-ACR1-ED3','new_engineering_runs':False,'figures':records},indent=2)+'\n');print('Built',len(records),'source-grounded ED3 figures')
