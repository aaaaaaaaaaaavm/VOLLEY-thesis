-- Resolve the report's local evidence links within its self-contained repository.
-- Exact source/export identities are held in REPORT_ISSUE.json and artifact manifests.
function RawBlock(el)
  if FORMAT=='docx' and el.format=='tex' and el.text:match('\\clearpage') then
    return pandoc.RawBlock('openxml','<w:p><w:r><w:br w:type="page"/></w:r></w:p>')
  end
end
local short_figures={"Integrated Gen5 ACR1 assembly","Selected guided-feed subassembly","Pallet handoff and carrier locks","Source-level captured payload","Operating cycle and positive custody","Finite motor force coefficients","Principal 3 m/s source-coupled trace","Nominal shot energy allocation","Carrier docked with lift clear","CalculiX chassis mesh and paired closure","Matched-load ANSYS static cross-check","Matched mission resource comparison"}
local short_tables={"Abbreviations and notation","Objectives, methods and evidence","Gen5 ACR1 reference definition","Six-case principal timestep audit","CalculiX chassis closure result","Matched-load cross-solver closure screen","Current study mass boundaries","Electrical/control mass allowance","End-frame rigid datum-stack sensitivity","Conductor thermal budgets","Compliance-energy sensitivity","Matched-state mission candidates","Current computational results","Numerical and CAD evidence trail","Proposed Gen6 validation activities"}
local figure_number=0
local table_number=0
local function caption_prefix(caption,label)
  if #caption.long>0 and caption.long[1].content then
    table.insert(caption.long[1].content,1,pandoc.Str(label..':'))
    table.insert(caption.long[1].content,2,pandoc.Space())
  end
end
function Figure(el)
  figure_number=figure_number+1
  if FORMAT=='docx' then caption_prefix(el.caption,'Figure '..figure_number)
  elseif FORMAT=='latex' then el.caption.short=pandoc.Inlines({pandoc.Str(short_figures[figure_number] or '')}) end
  return el
end
function Table(el)
  table_number=table_number+1
  if FORMAT=='docx' then caption_prefix(el.caption,'Table '..table_number)
  elseif FORMAT=='latex' then el.caption.short=pandoc.Inlines({pandoc.Str(short_tables[table_number] or '')}) end
  return el
end
