"""Editable 17-slide, two-speaker VOLLEY computational-study presentation."""
from pathlib import Path
import json,hashlib,shutil,datetime
from PIL import Image
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE,MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN,MSO_ANCHOR
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;ASSET=HERE/'assets';ASSET.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assets={p.name:{'source':'assets/'+p.name,'sha256':sha(p)} for p in ASSET.glob('*') if p.is_file()}
(HERE/'ASSET_SOURCES.json').write_text(json.dumps(assets,indent=2)+'\n')
input_paths=[ROOT/'cad/release/FINAL_CAD_MANIFEST.json',ROOT/'analysis/COUPLED_SHOT.json',ROOT/'analysis/FINITE_MOTOR.json',ROOT/'analysis/CURRENT_FIELD_FORCE.json',ROOT/'analysis/DESIGN_BUDGETS.json',ROOT/'verification/COUPLED_SHOT_REVIEW.json',ROOT/'mission/MISSION_CAPTURE.json',ROOT/'mission/MISSION_COMPARISON.json',ROOT/'academic/GEN5_FINAL_YEAR_REPORT.md']
inputs={str(p.relative_to(ROOT)):sha(p)for p in input_paths}
shot=json.loads((ROOT/'analysis/COUPLED_SHOT.json').read_text());case=next(c for c in shot['cases']if c['target_m_s']==3 and not c['adverse']and c['inductance_H']==2e-5)
budgets=json.loads((ROOT/'analysis/DESIGN_BUDGETS.json').read_text());review=json.loads((ROOT/'verification/COUPLED_SHOT_REVIEW.json').read_text());assert review['summary']['all_refined_cases_pass']
assert abs(shot['sled_mass_from_home_capture_kg']-13.127805767068676)<1e-8
P=Presentation();P.slide_width=Inches(13.333333);P.slide_height=Inches(7.5)
P.core_properties.title='VOLLEY: Design and Computational Evaluation of a Commanded Electromagnetic CubeSat Deployment Mechanism';P.core_properties.author='Adityavardhan Mishra; Pratham Chawla';P.core_properties.subject='B.Tech Mechanical Engineering computational design study';P.core_properties.keywords='VOLLEY, CubeSat, electromagnetic deployment, Gen5 ACR1 ED3';P.core_properties.last_modified_by='Adityavardhan Mishra; Pratham Chawla'
NAVY='102A43';COPPER='A9683D';INK='26384B';MUTED='617386';PALE='EFF3F7';BLUE='E4EDF5';WHITE='FFFFFF';LINE='CFD8E1'
FONT='Liberation Sans';records=[];notes=[]
times=[30,20,65,90,70,60,80,35,70,70,55,65,65,65,30,20,10]

def rect(s,x,y,w,h,fill=WHITE,line=None,radius=False):
 q=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h));q.fill.solid();q.fill.fore_color.rgb=RGBColor.from_string(fill)
 if line:q.line.color.rgb=RGBColor.from_string(line);q.line.width=Pt(.6)
 else:q.line.fill.background()
 return q

def text(s,value,x,y,w,h,size=20,color=INK,bold=False,align=PP_ALIGN.LEFT):
 q=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=q.text_frame;tf.clear();tf.word_wrap=True;tf.margin_left=0;tf.margin_right=0;tf.margin_top=0;tf.margin_bottom=0
 for i,line in enumerate(value.split('\n')):
  p=tf.paragraphs[0]if i==0 else tf.add_paragraph();p.text=line;p.alignment=align;p.space_before=Pt(0);p.space_after=Pt(3);p.line_spacing=1.08
  for r in p.runs:r.font.name=FONT;r.font.size=Pt(size);r.font.bold=bold;r.font.color.rgb=RGBColor.from_string(color)
 return q

def bullet(s,items,x,y,w,size=21,gap=.74,color=INK):
 for i,value in enumerate(items):text(s,'•',x,y+i*gap,.20,.35,size=size,color=COPPER,bold=True);text(s,value,x+.30,y+i*gap,w-.30,gap-.08,size=size,color=color)

def line(s,x1,y1,x2,y2,color=COPPER,width=1.2):
 q=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2));q.line.color.rgb=RGBColor.from_string(color);q.line.width=Pt(width);return q

def picture(s,name,x,y,w,h,cad=False):
 path=ASSET/name
 with Image.open(path)as im:iw,ih=im.size
 ch=.79 if cad else 1;ratio=iw/(ih*ch);dw=min(w,h*ratio);dh=dw/ratio
 q=s.shapes.add_picture(str(path),Inches(x+(w-dw)/2),Inches(y+(h-dh)/2),width=Inches(dw),height=Inches(dh))
 if cad:q.crop_top=.095;q.crop_bottom=.115
 records[-1]['images'].append({'asset':name,'source':assets[name],'cad_caption_crop':{'top':.095,'bottom':.115}if cad else None})
 return q

def metric(s,value,label,x,y,w=3.0,h=1.1,fill=PALE,value_size=31):
 rect(s,x,y,w,h,fill);rect(s,x,y,.055,h,COPPER)
 if h<1:text(s,value,x+.18,y+.04,w-.30,.44,size=value_size,color=NAVY,bold=True);text(s,label,x+.18,y+.52,w-.30,h-.54,size=12.8,color=MUTED)
 else:text(s,value,x+.18,y+.12,w-.30,.48,size=value_size,color=NAVY,bold=True);text(s,label,x+.18,y+.67,w-.30,h-.69,size=14,color=MUTED)

def table(s,heads,rows,x,y,widths,row_h=.68,font=18):
 xx=x
 for head,w in zip(heads,widths):rect(s,xx,y,w,row_h,NAVY);text(s,head,xx+.12,y+.12,w-.22,row_h-.16,size=font,color=WHITE,bold=True);xx+=w
 for n,row in enumerate(rows):
  xx=x;yy=y+(n+1)*row_h
  for cell,w in zip(row,widths):rect(s,xx,yy,w,row_h,PALE if n%2==0 else WHITE);text(s,str(cell),xx+.12,yy+.11,w-.22,row_h-.12,size=font,color=INK);xx+=w

def new(title,section,source='',subtitle=''):
 s=P.slides.add_slide(P.slide_layouts[6]);n=len(P.slides);records.append({'slide':n,'title':title,'section':section,'images':[],'sources':source,'speaker':'Adityavardhan Mishra'if n<=8 else'Pratham Chawla','planned_seconds':times[n-1]})
 rect(s,0,0,13.333,.065,NAVY);text(s,'VOLLEY  /  GEN5 ACR1',.55,.16,7,.22,size=11,color=COPPER,bold=True);text(s,section.upper(),10.1,.16,2.68,.22,size=11,color=MUTED,align=PP_ALIGN.RIGHT)
 text(s,title,.55,.51,12.2,.70,size=28,color=NAVY,bold=True)
 if subtitle:text(s,subtitle,.55,1.18,12.2,.45,size=15.5,color=MUTED)
 line(s,.55,6.97,12.78,6.97,color=LINE,width=.7);text(s,source,.55,7.07,11.4,.24,size=10.2,color=MUTED);text(s,f'{n:02d} / 17',11.9,7.04,.86,.30,size=12,color=NAVY,align=PP_ALIGN.RIGHT)
 return s

def note(s,body):
 r=records[-1];start=sum(times[:r['slide']-1]);end=start+r['planned_seconds'];fmt=lambda t:f'{t//60}:{t%60:02d}'
 value=f"Speaker: {r['speaker']}\nPlanned time: {r['planned_seconds']} s ({fmt(start)}–{fmt(end)})\n\n{body}\n\nSource basis: {r['sources']}"
 s.notes_slide.notes_text_frame.text=value;notes.append({'slide':r['slide'],'title':r['title'],'speaker':r['speaker'],'seconds':r['planned_seconds'],'start_s':start,'end_s':end,'script':body,'source_basis':r['sources']})

# 1 — title
s=new('', 'B.Tech project presentation','Symbiosis Institute of Technology, Pune | October 2026')
text(s,'DEPARTMENT OF MECHANICAL ENGINEERING',.55,.61,8,.34,size=14,color=MUTED,bold=True);text(s,'VOLLEY',.55,1.30,7,.67,size=42,color=NAVY,bold=True)
text(s,'Design and Computational Evaluation\nof a Commanded Electromagnetic\nCubeSat Deployment Mechanism',.55,2.12,7.35,2.10,size=27,color=NAVY,bold=True)
text(s,'GEN5 ACR1  |  COMPUTATIONAL DESIGN STUDY',.57,4.28,7.2,.38,size=13.5,color=COPPER,bold=True)
text(s,'Adityavardhan Mishra\nPRN: 23070125054',.55,5.02,3.7,.85,size=18,color=INK);text(s,'Pratham Chawla\nPRN: 23070125029',4.20,5.02,3.6,.85,size=18,color=INK)
text(s,'Project guide: Vikas Gulia',.55,6.15,7,.42,size=19,color=INK);picture(s,'sit-logo.jpg',10.30,.53,2.45,.80);picture(s,'assembly_hero.png',7.9,2.1,4.9,3.9)
text(s,'Symbiosis Institute of Technology, Pune',7.9,6.22,4.9,.45,size=16,color=MUTED,align=PP_ALIGN.RIGHT)
note(s,'Good morning. We are Adityavardhan Mishra and Pratham Chawla, presenting VOLLEY under the guidance of Vikas Gulia. This project develops and computationally evaluates a commanded electromagnetic CubeSat deployment mechanism. The presentation focuses on the completed Gen5 ACR1 computational reference and the physical validation proposed for Gen6.')
# 2 — outline
s=new('Presentation outline','Outline','College presentation structure adapted to the VOLLEY study')
for n,(head,detail)in enumerate([('01  Motivation and prior work','Introduction, literature, research gap and objectives'),('02  Method and progress','Controlled configuration and dependent numerical models'),('03  Mechanism and results','Payload custody, finite motor, source, structure and mission'),('04  Conclusions and next steps','Study outcome, Gen6 prototype and references')]):
 y=1.65+n*1.18;rect(s,.65,y,12.0,.94,PALE);text(s,head,.87,y+.15,4.6,.44,size=23,color=NAVY,bold=True);text(s,detail,5.45,y+.21,6.95,.52,size=18,color=MUTED)
note(s,'We begin with the deployment problem and relevant prior work, then define the research gap and objectives. We explain the computational method and progress before moving to the mechanism and results. We close with the mission trade, conclusions and the proposed Gen6 validation programme.')
# 3 — introduction
s=new('Commanded release adds a local delivery variable','Introduction','Sources: JAXA deployment ICD; Cal Poly CDS Rev. 14.1; Foster et al. (2018); Vallado (2013)')
rect(s,.65,1.55,5.35,4.95,PALE);text(s,'DEPLOYMENT EVENT - SCHEMATIC',.90,1.80,4.9,.35,size=15,color=COPPER,bold=True)
planet=s.shapes.add_shape(MSO_SHAPE.OVAL,Inches(1.23),Inches(2.62),Inches(2.75),Inches(2.75));planet.fill.solid();planet.fill.fore_color.rgb=RGBColor.from_string(BLUE);planet.line.color.rgb=RGBColor.from_string(LINE)
text(s,'Earth',2.05,3.75,1.15,.40,size=21,color=MUTED,align=PP_ALIGN.CENTER);rect(s,4.35,2.68,.60,.42,NAVY);rect(s,5.06,2.40,.22,.22,COPPER);line(s,4.96,2.77,5.54,2.77,COPPER,2.2);text(s,'Host',4.30,3.25,1.2,.35,size=18,color=NAVY);text(s,'Relative\nrelease',4.65,3.85,1.0,.76,size=17,color=COPPER);text(s,'Concept only; arrows are not to scale.',.90,5.78,4.8,.45,size=13,color=MUTED)
bullet(s,['Host manoeuvres establish the carrier state.','A release command changes the payload initial condition relative to the host.','Retention, guidance, arrest and host recoil complete the system boundary.'],6.55,1.84,6.1,size=22,gap=1.27)
text(s,'Research question',6.85,5.86,5.5,.35,size=15,color=COPPER,bold=True);text(s,'Can a twelve-payload system complete a\ncoupled, reusable deployment cycle?',6.85,6.18,5.4,.66,size=19,color=NAVY,bold=True)
note(s,'A deployer is an interface between a host platform and a free-flying spacecraft. The host can manoeuvre before release, while the deployer sets a local relative velocity at a specific event. These are related but distinct controls. A release impulse can change orbital energy and subsequent phasing, and its usefulness depends on the delivery objective and the available host resources. Our schematic identifies the event rather than depicting a flight vehicle. The design question is therefore broader than generating force. The payload must remain retained and guided before command, the moving carrier must be arrested and returned, and its momentum and installed mass must remain in the mission budget. This is the system boundary used throughout the study.')
# 4 — literature
s=new('Prior work establishes the mechanisms and comparison context','Literature review','Sources: Zhao et al. (2022, 2025); Feng et al. (2025); Halbach (1980); Yamaguchi & Morishita (2023)')
table(s,['Published work','Evidence / interface','Implication for VOLLEY'],[
 ['Zhao et al., 2022\nStacked EM deployment','Gravity-compensated tests;\nstacked CubeSat release','Distinguish published measurements\nfrom the present computational results.'],
 ['Zhao et al., 2025\nHigh-volume storage','Receiving guides and magnetic transfer;\npayload grooves and iron patches','Define the passive payload interface\nand receiving custody explicitly.'],
 ['Feng et al., 2025\nEM reachable domain','Higher-speed launcher and\nmission-domain analysis','Couple the selected operating regime\nto its energy and mission assumptions.'],
 ['Halbach; finite-motor studies','Permanent-magnet field shaping\nand longitudinal end effects','Use finite magnet and conductor\ngeometry at launch and arrest.']
],.65,1.62,[3.05,4.48,4.50],row_h=.88,font=17)
text(s,'Study focus: integration and same-revision evaluation of a retained-carrier architecture.',.80,6.40,11.8,.40,size=20,color=NAVY,bold=True)
note(s,'Electromagnetic CubeSat deployment and high-volume storage are established prior art. Zhao and colleagues reported stacked electromagnetic release in 2022, including gravity-compensated laboratory tests. Their measured velocities belong to their mechanism, payloads and test conditions. The 2025 storage study examines pushing, receiving guides and magnetic transport, including spacecraft-side grooves and iron patches. That interface differs from the passive rectangular envelope represented here. Feng and colleagues examine a higher-speed launcher and reachable domain, which provides mission context but uses a different operating regime. Halbach supplies the permanent-magnet field concept, while finite-motor literature identifies the importance of longitudinal end effects. The present contribution is the integration and evaluation of one explicit retained-carrier reference: custody, finite force, source limits, arrest and host burden are assessed together. We preserve the distinction between third-party experimental evidence and our numerical results.')
# 5 — research gap
s=new('Research gap: closing the complete retained-carrier cycle','Research gap','Basis: literature synthesis and the defined Gen5 ACR1 system boundary')
for x,head,body in [( .65,'Who holds the payload?','A complete custody path through cell opening, receiving, docking and commanded departure.'),(4.80,'Can the source deliver it?','Finite force, actual moving mass, current dynamics and post-release arrest evaluated together.'),(8.95,'What does the host retain?','The reusable carrier, installed hardware, power allowance and recoil carried into mission comparison.')]:
 rect(s,x,1.85,3.73,3.75,PALE);rect(s,x,1.85,3.73,.07,COPPER);text(s,head,x+.22,2.20,3.28,.80,size=25,color=NAVY,bold=True);text(s,body,x+.22,3.28,3.28,1.90,size=21,color=INK)
text(s,'One design links payload custody, electromechanics and mission resources.',.85,5.93,11.5,.42,size=21,color=NAVY,bold=True)
text(s,'Positive custody precedes each handoff; the same carrier serves launch, arrest and return.',.85,6.43,11.5,.42,size=18,color=MUTED)
note(s,'The research gap addressed here is integration at a defined reference boundary. First, a storage-to-release mechanism needs an explicit answer to who holds the payload at every transition. Second, a useful electromagnetic result requires the force map, real moving mass and electrical source to be solved as one problem, including what happens after the spacecraft separates. Third, the retained carrier and installed hardware affect the host even when the payload has departed. The study connects these questions using one controlled mechanical revision. This supplies a reproducible basis for evaluating operating cases and for deciding which measurements a physical prototype must provide. It is a design-specific integration contribution rather than a claim that adjustable electromagnetic ejection is a new principle.')
# 6 — objectives
s=new('Objectives and controlled reference requirements','Objectives','Sources: frozen CAD manifest; PARAMETERS.json; coupled operating-study definition')
for x,y,value,label in [(.65,1.75,'12 × 4 kg','Identical 3U envelope surrogates'),(6.82,1.75,'1–3 m/s','Analysed commanded-speed cases'),(.65,3.23,'2250 mm','Guide-rail allocation'),(6.82,3.23,'210 mm','Post-release arrest allocation')]:metric(s,value,label,x,y,5.86,1.16,value_size=33)
bullet(s,['Define continuous payload custody and a reusable carrier cycle.','Evaluate finite motor force with the represented winding and magnet geometry.','Couple source, release and arrest; assess structural and mission consequences.'],.82,4.92,11.75,size=20,gap=.57)
note(s,'The reference manifest contains twelve identical four-kilogram 3U envelope surrogates. The represented contact envelope is 340.5 by 100 by 100 millimetres. The current computational operating study covers commands from one to three metres per second. The rail is 2250 millimetres long, and the post-release arrest allocation is 210 millimetres. Within this boundary, the objectives are to define continuous payload custody, evaluate the finite motor geometry, solve the coupled source and mechanical cycle, and carry the retained burden into structural and mission evaluation. These values identify the analysed configuration. The later mixed-size prototype will need its own payload interfaces and verification rather than inheriting this twelve-3U definition.')
# 7 — four connected modelling steps
s=new('One source chain connects the machine to the mission','Research methodology','Sources: accepted ACR1 CAD, force/current, source-coupled shot, structural and mission records')
steps=[('1','Define the machine','Geometry, mass and custody'),('2','Solve the shot','Finite force + source + arrest'),('3','Check the structure','Loads, gap and declared budgets'),('4','Compare the mission','Same targets; full retained mass')]
for i,(n,head,body) in enumerate(steps):
 x=.65+i*3.12;rect(s,x,2.05,2.87,2.55,PALE);text(s,n,x+.20,2.27,2.45,.50,size=34,color=COPPER,bold=True);text(s,head,x+.20,3.02,2.48,.64,size=22,color=NAVY,bold=True);text(s,body,x+.20,3.83,2.48,.60,size=17,color=INK)
 if i<3:line(s,x+2.89,3.34,x+3.10,3.34,COPPER,2)
text(s,'Cross-check each model at its own boundary.',.85,5.35,11.6,.47,size=25,color=NAVY,bold=True)
text(s,'Native / STEP geometry  •  field and current formulations  •  refined shot / native orbit replay',.85,6.10,11.6,.55,size=19,color=MUTED)
note(s,'The source chain begins with geometry, retained mass and custody. Those inputs enter the finite motor and source-coupled shot, including release and arrest. The resulting forces support the structural and interface budgets. The achieved release map and full installed burden then enter the same-target mission comparison. Independent checks have different roles: native and STEP readback test exchanged geometry, alternative field and current formulations check numerical approximations, the principal shot is timestep refined, and Orekit replays the mission trajectories. The corrected ANSYS static comparison adds a separate solver under matched bare-chassis assumptions. This dependency chain keeps the results on one declared ACR1 reference.')
# 8 — progress
s=new('Timeline and work progress','Timeline / work progress','Academic edition ED3: October 2026 | Gen6 physical prototype is future development')
stages=[('Problem and literature','Complete'),('Gen5 ACR1 definition','Complete'),('Coupled computational study','Complete'),('Report and presentation','Academic edition ED3'),('Gen6 instrumented prototype','Future work')]
for i,(head,status)in enumerate(stages):
 x=.65+i*2.49;fill=PALE if i<4 else BLUE;rect(s,x,2.08,2.29,2.80,fill);text(s,f'{i+1:02d}',x+.17,2.31,1.9,.43,size=28,color=COPPER,bold=True);text(s,head,x+.17,3.08,1.96,.86,size=20,color=NAVY,bold=True);text(s,status,x+.17,4.24,1.96,.45,size=15.5,color=MUTED)
text(s,'Completed outcome',.80,5.55,3.4,.35,size=15,color=COPPER,bold=True);text(s,'A controlled computational design reference with defined operating cases and a hardware validation programme.',.80,5.98,11.7,.72,size=24,color=NAVY,bold=True)
note(s,'The work has progressed from literature and problem framing to the Gen5 ACR1 reference, followed by the coupled computational study. The current stage is the academic report and presentation capture. The computational design study is complete within its stated reference cases. Gen6 is the proposed physical development stage, beginning with an instrumented mixed 1U and 3U prototype. Pratham will now explain the reference mechanism and the engineering results.')
# 9 — architecture
s=new('Reference architecture: fixed banks and one captive pallet','Architecture','CAD-derived render: frozen ACR1 home pose; all 387 represented parts; declared reference components')
picture(s,'ED3_assembly_guide.png',.53,1.53,8.35,4.97)
metric(s,'2 × 6 cells','Fixed, individually retained storage',9.13,1.68,3.55,1.10)
metric(s,'13.128 kg','Retained moving carrier + pallet',9.13,3.00,3.55,1.10)
metric(s,'149.557 kg','Represented dry CAD mass',9.13,4.32,3.55,1.10)
text(s,'+7 kg power/control allowance',9.20,5.76,3.5,.40,size=16,color=COPPER,bold=True);text(s,'Magnet arrays stay on the carrier.',9.20,6.28,3.45,.42,size=15.5,color=MUTED)
text(s,'1 Storage  ·  2 Lift  ·  3 Carrier/pallet  ·  4 Stator + track',.70,6.57,7.9,.32,size=16,color=NAVY,bold=True)
note(s,'The reference mechanism has two fixed banks with six cells per bank. Positive guided pushers feed one selected payload toward the central lift. The lift carries a single captive pallet, and that same physical pallet docks to the launch carrier. The magnet arrays remain on the reusable carrier rather than on the payload. This is the complete native CAD home state, including the storage banks and generic mounting ladder. The retained moving carrier, pallet, lock pins and reference actuators total 13.128 kilograms. Represented dry CAD mass is 149.557 kilograms, with a separate seven-kilogram power and control allowance. These masses are part of the system assessment. They are material-volume and assigned-reference totals, rather than a weighed physical article.')
# 10 — one large custody interface
s=new('Capture before release: one pallet, two holders','Feeder and pallet','CAD-derived ACR1 handoff pose; banks, host ladder and fixed lift frame hidden to expose the interfaces')
picture(s,'02_handoff_pallet_locks.png',.55,1.65,7.62,4.83,cad=True)
for i,(head,body) in enumerate([('1  Lift holds','The lift grips retain the pallet while it lands.'),('2  Carrier captures','Caps and both bayonet locks prove receiving custody.'),('3  Lift clears','Only then do the lift grips withdraw and the lift rise.')]):
 y=1.85+i*1.52;text(s,head,8.65,y,4.00,.48,size=25,color=NAVY,bold=True);text(s,body,8.65,y+.61,4.00,.78,size=20,color=INK)
text(s,'The pallet stays on the carrier through launch, arrest and return.',.80,6.55,11.8,.37,size=19,color=COPPER,bold=True)
note(s,'This enlarged native CAD handoff view shows the receiving interface. The lift still holds the pallet while its four feet land on the carrier. The upper capture caps and both bayonet locks engage and prove receiving custody before the lift grip pins retract. The lift then rises clear. That same pallet stays on the retained carrier during launch, arrest and return. The view hides the banks, host ladder and fixed lift frame to expose the actual interfaces. Fixed passive cams later open the forekeepers through twelve millimetres over fifty millimetres of carrier travel, completing five millimetres before release. Slow guided transfer and position-defined release remain distinct parts of the cycle.')
# 11 — one force result
s=new('Finite geometry gives the force used by the shot model','Electromagnetic simulation','Source: FINITE_MOTOR.json; CURRENT_FIELD_FORCE.json | coefficients use peak phase current')
picture(s,'ED3_force.png',.55,1.65,8.05,4.72)
text(s,'1.399 N/A',9.05,2.00,3.50,.70,size=34,color=COPPER,bold=True)
text(s,'Interior model, including represented returns',9.05,2.87,3.45,1.00,size=21,color=NAVY,bold=True)
text(s,'0.172%',9.05,4.20,3.50,.65,size=33,color=COPPER,bold=True)
text(s,'Local actual-current FEM difference under the same permanent field',9.05,5.01,3.45,1.10,size=19,color=MUTED)
text(s,'42 + 42 discrete magnets  •  216 active bars  •  finite conductor and return geometry',.80,6.55,11.8,.36,size=18,color=NAVY,bold=True)
note(s,'The motor has forty-two discrete magnet blocks on each opposed retained array and two hundred and sixteen active stator bars. The graph shows the captured force-position coefficients. Active conductors give approximately 1.3287 newtons per peak phase ampere in the interior. Represented return conductors bring the simpler result to about 1.3991. Actual conductor-current FEM differs by 0.172 percent at the checked interior station under the same permanent field. This is local model agreement, not a physical accuracy bound. Position dependence is retained in the source-coupled launch and arrest calculations. Force, resistance, inductance and back-emf correlation are defined measurements for the later physical prototype.')
# 12 — one speed trace
s=new('The carrier accelerates, releases, then arrests','Simulation results','Captured nominal 3 m/s, 20 µH source-coupled case | speed is carrier relative to host')
picture(s,'ED3_shot_speed.png',.55,1.65,8.05,4.80)
metric(s,f"{case['release']['relative_speed_m_s']:.3f} m/s",'Modeled speed at departure',9.05,1.95,3.55,1.18,value_size=30)
metric(s,f"{case['cap_draw_J']:.1f} J",'Nominal source draw',9.05,3.49,3.55,1.18,value_size=30)
text(s,'6 / 6 principal cases pass the 5 µs timestep audit.',9.05,5.20,3.55,1.08,size=21,color=NAVY,bold=True)
text(s,'Release near 1.300 m  →  carrier stops at 1.507 m within the 210 mm arrest allocation.',.80,6.55,11.8,.36,size=18,color=COPPER,bold=True)
note(s,'This single trace follows carrier speed relative to the host. The loaded carrier accelerates, and electrical braking reduces the rear-contact reaction to zero near 1.3 metres. The payload then departs while the carrier and pallet remain on the rail. The motor actively arrests the retained carrier at 1.507 metres, within the allocated 210 millimetres after release. The nominal twenty-microhenry case gives a release speed of 2.999864 metres per second and source draw of 379.7 joules. Six principal three-metre-per-second nominal/adverse and inductance cases pass the reviewed five-microsecond timestep audit. The detailed current, voltage, loss and thermal evidence remains in the report. Conservation and numerical agreement support the stated model; measured device temperatures and release distributions require physical correlation.')
# 13 — one matched static comparison
s=new('A second solver agrees under the matched chassis boundary','Structure and contact','Sources: CalculiX reference and corrected ANSYS native-result audit | same bare-chassis loads and restraints')
picture(s,'ED3_static_comparison.png',.55,1.65,8.05,4.80)
text(s,'+0.143%',9.05,2.00,3.50,.72,size=39,color=COPPER,bold=True)
text(s,'Primary ANSYS difference from CalculiX',9.05,2.93,3.50,1.05,size=23,color=NAVY,bold=True)
text(s,'Three ANSYS meshes',9.05,4.38,3.50,.52,size=21,color=NAVY,bold=True)
text(s,'Sensitivity evidence; no formal error bound.',9.05,5.08,3.50,.90,size=19,color=MUTED)
text(s,'Opposed 3.010 kN patches  •  six scalar numerical restraints  •  native-result sample readback',.80,6.55,11.8,.36,size=17.5,color=NAVY,bold=True)
note(s,'The corrected ANSYS package checks the same bare chassis, material, opposed 3.010-kilonewton patch forces and six scalar numerical restraints. Primary paired closure is 0.286392 millimetres against 0.285983 from CalculiX, a difference of 0.143 percent. The three ANSYS meshes span 0.285241 to 0.287589 millimetres. They supply sensitivity evidence rather than a formal convergence or error guarantee. Independent native-result interpolation reproduces all 11,448 primary samples. The existing face budget remains tied to CalculiX: applying its explicit centred formula to the finest ANSYS peak gives a conditional 0.263067 millimetres instead of 0.264111. This comparison does not establish actual assembled clearance. Contact-energy rate bounds remain separate in the report; support behavior and physical qualification require their own evidence.')
# 14 — one decisive mission comparison
s=new('The preplanned mission trade favours ideal ground pretrim','Mission results','Selected alternating 1 / 3 m/s targets · 5 N host authority | lowest-fuel feasible tested policies')
picture(s,'ED3_mission_fuel.png',.55,1.65,8.05,4.75)
text(s,'84.557 kg',9.05,2.02,3.50,.68,size=33,color=COPPER,bold=True)
text(s,'Additional retained device mass in the study',9.05,2.88,3.50,1.08,size=22,color=NAVY,bold=True)
text(s,'156.557 kg VOLLEY\n72 kg spring class',9.05,4.38,3.50,1.05,size=22,color=NAVY,bold=True)
text(s,'Spring mass is a declared class-study assumption.',9.05,5.62,3.50,.71,size=17,color=MUTED)
text(s,'Same 500 kg wet bus + 48 kg payload; device mass and release/burn policies differ.',.80,6.55,11.8,.36,size=17.5,color=NAVY,bold=True)
note(s,'The displayed selected case uses alternating one and three metre-per-second target families and a five-newton host ceiling. VOLLEY uses about 0.28987 kilograms of host fuel; ideal ground pretrim uses about 0.05365. Both use the same five-hundred-kilogram wet bus and twelve four-kilogram payloads, while retained device mass differs. VOLLEY retains 156.557 kilograms against the declared seventy-two-kilogram spring-class assumption. The initial wet totals are 704.557 and 620 kilograms. In the uniform two-metre-per-second family, VOLLEY uses 0.05244 kilograms and fixed spring uses 0.04696. Pretrim also has a tested one-newton alternating solution. These preplanned cases demonstrate no mass or fuel advantage. The full table records different release/burn guards, and failure within sampled policies is not global infeasibility.')
# 15 — conclusions
s=new('Conclusions of the computational design study','Conclusion','Basis: controlled Gen5 ACR1 geometry, coupled simulations, independent checks and mission comparison')
for i,(head,body)in enumerate([('A complete reference cycle is defined','Fixed cells, guided feed, positive pallet capture, commanded release, active arrest and return.'),('The declared low-speed cases are computationally supported','1–3 m/s cases analysed; the principal 3 m/s matrix passes a reviewed shared-solver timestep audit.'),('The retained system burden is visible','149.557 kg represented dry CAD plus 7 kg allowance; no resource advantage over ideal pretrim in the stated mission comparison.')]):
 y=1.72+i*1.52;rect(s,.65,y,12.0,1.35,PALE);rect(s,.65,y,.065,1.35,COPPER);text(s,head,.90,y+.15,11.45,.40,size=23,color=NAVY,bold=True);text(s,body,.90,y+.68,11.45,.62,size=19,color=INK)
text(s,'Gen5 ACR1 completes the computational reference for physical validation.',.85,6.46,11.6,.41,size=22,color=NAVY,bold=True)
note(s,'The study produces a complete computational reference for a repeated deployment cycle, from retained storage to carrier return. The declared low-speed cases are evaluated with finite motor geometry, actual retained mass and a stated source, and the principal three-metre-per-second cases receive an independently reviewed shared-solver timestep audit. The system burden remains substantial and the mission comparison supplies no mass or fuel advantage over ideal pretrim. This defines the outcome and the next physical validation step.')
# 16 — future
s=new('Gen6: an instrumented mixed 1U / 3U physical prototype','Future work','Proposed development programme; no measured VOLLEY prototype performance is reported')
for x,head,body in [(.65,'1  Characterise','Force / back emf\nResistance and inductance\nSource ESR and switching'),(4.80,'2  Correlate custody','Pusher and guide forces\nPallet and lock repeatability\nPayload contact and angular rate'),(8.95,'3  Demonstrate the cycle','Release and active arrest\nRepeated thermal duty\nMixed-envelope handling')]:
 rect(s,x,1.85,3.73,3.65,PALE);text(s,head,x+.22,2.18,3.28,.66,size=23,color=NAVY,bold=True);text(s,body,x+.22,3.14,3.28,1.94,size=20,color=INK)
text(s,'Further scaling requires fresh stroke, acceleration, energy, arrest and heat-rejection budgets.',.85,6.12,11.5,.66,size=23,color=COPPER,bold=True)
note(s,'Gen6 is the proposed physical prototype stage. It should characterise the motor and source, correlate custody and contact behaviour, and then demonstrate instrumented release, arrest and repeated duty. Mixed one-unit and three-unit handling needs fresh envelopes, retention definitions and mass accounting. Higher-speed scaling requires new coupled energy, acceleration, arrest and thermal budgets.')
# 17 — references
s=new('Selected references','References','Full bibliography, source data sheets and engineering provenance accompany the report')
refs=[
 'Cal Poly, CubeSat Design Specification Rev. 14.1; JAXA, JEM small-satellite deployment ICD.',
 'Zhao et al. (2022), stacked CubeSat deployer. Remote Sensing 14, 4205. doi:10.3390/rs14174205.',
 'Zhao et al. (2025), high-volume storage transport. Aerospace 12, 466. doi:10.3390/aerospace12060466.',
 'Feng, Yang and Wu (2025), electromagnetic launcher and reachable domain. IJAE 3000765. doi:10.1155/ijae/3000765.',
 'Halbach (1980), permanent-field design; Yamaguchi and Morishita (2023), finite-motor end effects. Full identities in report.',
 'Computational methods: FreeCAD, Magpylib, Gmsh, CalculiX, Orekit, Blender; corrected ANSYS static source supplement (2026).'
]
for i,r in enumerate(refs):
 col=0 if i<3 else 1;row=i%3;text(s,f'{i+1:02d}',.65+col*6.18,1.75+row*1.48,.35,.34,size=15,color=COPPER,bold=True);text(s,r,1.12+col*6.18,1.75+row*1.48,5.43,1.27,size=17,color=INK)
text(s,'Questions',.80,6.57,11.8,.39,size=22,color=NAVY,bold=True)
note(s,'These selected references support the interface assumptions, prior-work comparison and numerical methods. The full bibliography and traceable engineering records accompany the report. Thank you; we welcome questions.')
assert len(P.slides)==17 and sum(times)==900 and sum(times[:8])==450 and sum(times[8:])==450
out=HERE/'VOLLEY_BTech_Presentation.pptx';temporary=HERE/'VOLLEY_BTech_Presentation.tmp.pptx';P.save(temporary);temporary.replace(out)
(HERE/'SPEAKER_NOTES.json').write_text(json.dumps(notes,indent=2)+'\n')
lines=['# VOLLEY — 15-minute two-speaker presentation','', 'Delivery allocation: Adityavardhan Mishra, slides 1–8 (7 min 30 s); Pratham Chawla, slides 9–17 (7 min 30 s). This allocates speaking time without assigning individual research contributions.','']
for n in notes:lines += [f"## {n['slide']:02d}. {n['title']}",f"{n['speaker']} — {n['seconds']} seconds",'',n['script'],'']
(HERE/'SPEAKER_NOTES.md').write_text('\n'.join(lines))
manifest={'title':P.core_properties.title,'authors':[{'name':'Adityavardhan Mishra','PRN':'23070125054'},{'name':'Pratham Chawla','PRN':'23070125029'}],'guide':'Vikas Gulia','slide_count':17,'planned_duration_s':900,'speakers':[{'name':'Adityavardhan Mishra','slides':[1,8],'seconds':450},{'name':'Pratham Chawla','slides':[9,17],'seconds':450}],'template_structure_source':'Department B.Tech presentation format; implemented in this source','input_sha256':inputs,'asset_sources':assets,'slides':records,'build_script_sha256':sha(Path(__file__)),'pptx_sha256':sha(out),'statement':'Completed computational design study; Gen6 physical prototype is proposed future work. No individual research contributions are assigned.'}
(HERE/'PRESENTATION_PROVENANCE.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('BUILT',out,len(P.slides),sum(times),flush=True)
