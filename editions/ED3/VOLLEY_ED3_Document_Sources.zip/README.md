# VOLLEY academic edition ED3 — document sources

27 October 2026. The 58-page report and 17-slide, 15-minute presentation explain the completed Gen5 ACR1 computational study. ED3 adds a simple custody flow, annotated CAD overview and larger single-result slide figures, using unchanged accepted engineering data.

Assets are stored once under `shared_assets/`. Restore their original builder paths before building:

```sh
python3 materialize_assets.py --verify-only
python3 materialize_assets.py
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-documents.txt
.venv/bin/python current/academic/build_report.py
.venv/bin/python cache_docx_indexes.py
.venv/bin/python current/presentation/build_presentation.py
soffice --headless --convert-to pdf --outdir current/presentation current/presentation/VOLLEY_BTech_Presentation.pptx
```

Reference environment: Python 3.12, Pandoc 3.1.11.1, XeLaTeX from TeX Live 2025/dev, and LibreOffice 25.2.3.2. Install Liberation Serif/Sans and DejaVu Sans Mono. LaTeX uses the Pandoc default packages plus setspace, titlesec, caption, chngcntr and pgf/TikZ. Python document dependencies are pinned. The optional `requirements-figures.txt` and `build_visuals.py` regenerate the new ED3 figures from the captured inputs.

`ASSET_MAP.json`, `FIGURE_SOURCES.json` and `SOURCE_MANIFEST.json` identify exact source assets, plotted values, annotations and source hashes. `BUILD_REFERENCE.json` records the distributed document identities. Fonts, timestamps and runtime versions can change rebuilt binary identities. Refresh Word fields after Word repagination before printing a DOCX-derived edition.

The captured numerical inputs identify the computational evidence used in these documents. Native engineering regeneration uses the separately published ACR1 and matched static source packages. No additional engineering case or physical experiment was run to make this edition. The original ED1/ED2 artifacts retain their identities.
