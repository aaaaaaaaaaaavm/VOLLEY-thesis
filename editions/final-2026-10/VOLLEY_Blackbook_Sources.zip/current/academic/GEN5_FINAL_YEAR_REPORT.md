---
title: "VOLLEY: Design and Computational Evaluation of a Commanded Electromagnetic CubeSat Deployment Mechanism"
author:
  - Adityavardhan Mishra
  - Pratham Chawla
date: "28 October 2026"
lang: en-GB
papersize: a4
fontsize: 12pt
mainfont: Liberation Serif
sansfont: Liberation Sans
monofont: DejaVu Sans Mono
geometry:
  - left=32mm
  - right=25mm
  - top=25mm
  - bottom=25mm
---

# Abstract {.unnumbered .unlisted}

VOLLEY is a commanded electromagnetic deployment mechanism intended to assign individual relative release velocities to CubeSats carried by a manoeuvring host. This study develops and computationally evaluates the Gen5 reference design for twelve 4 kg, 3U envelope surrogates. Two fixed six-cell banks feed a vertically indexed captive pallet, which docks positively to a reusable permanent-magnet sled. A finite three-phase stator accelerates the payload and sled; passive cams open the forekeepers before release, and the same linear synchronous motor arrests and returns the sled. Eight native and STEP configuration states, along with 154 accepted motion/refinement checks support the nominal geometric compatibility of this project. Solid-volume accounting gives it a represented dry CAD mass of 149.557 kg and total of 197.557 kg when loaded with twelve payloads, with a separate 7 kg allowance retained for power/control. A three dimensional finite magnet integration approximates the active conductors to 1.328 N/A and to 1.399 N/A, when the represented returns are included. An independent source face integration confirms the active force, while a finite-element distribution integration differs by 0.172%. The principal 3 m/s source case passes all six nominal/adverse and 3/20/100 µH inductance combinations in an independently audited 5 µs time-step rerun, with arrest within the allocated 210 mm. Actual-chassis elasticity under opposed 3.010 kN array loads gives 0.286 mm paired gap closure, increasing to 0.372 mm under a declared 1.3 load multiplier. Together, these results support a computational operating study over 1–3 m/s and identify the source, mechanical custody and host resources required for it. Manufacturing, payload compatibility and environmental performance remain subjects for physical validation. A mixed 1U/3U prototype and higher-speed scaling are proposed as Gen6 development.

**Keywords:** CubeSat deployment; linear synchronous motor; finite magnetic field; payload custody; coupled electromechanical simulation; computational design.

# Abbreviations and notation {.unnumbered .unlisted}

| Symbol or term | Meaning |
|:--|:--|
| CAD / STEP | Computer-aided design / ISO 10303 solid exchange |
| CG / ICD | Centre of gravity / interface control document |
| FEM / FEA | Finite-element method / finite-element analysis |
| LSM / PWM | Linear synchronous motor / pulse-width modulation |
| ESR / SVPWM | Equivalent series resistance / space-vector PWM |
| $x$, $v$, $I$ | Relative travel, relative speed, peak phase current |
| $K_t$, $K_e$ | Position-dependent thrust and back-emf coefficients |
| $L$, $R$, $C$ | Effective winding inductance, resistance and source capacitance |
| $m_p$, $m_s$, $M_h$ | Payload, retained sled and remaining host masses |

: Abbreviations and principal notation.

\clearpage
\pagenumbering{arabic}

# Introduction and problem definition

## Commanded release from a hosted manifest

CubeSat deployment is an interface between a launch or transport platform and a free-flying spacecraft. A deployer must retain a payload before command, guide it along an agreed contact path, produce separation, and leave both spacecraft in acceptable states. Conventional spring dispensers provide this function with a compact mechanism and substantial operational heritage [1,2]. Where the mission requires distinct release conditions for individual members of a manifest, controllable velocity becomes an additional design variable.

A manoeuvring host can change its own orbit before release. A commanded deployer adds a local relative velocity at the release event. These actions affect different parts of the delivery problem: host manoeuvres establish the carrier state, while the deployment impulse establishes the payload state relative to that carrier. Along-track release changes orbital energy and period; a cross-track component changes the orbital plane to a much smaller extent for the same low relative speed. The useful direction and magnitude depend on the target states and the host's available resources [3,9].

VOLLEY investigates this additional release control by the use of a reusable moving-magnet LSM (linear synchronous motor). The payload remains as a passive envelope surrogate, while the added magnet arrays and the motor elements belong to the sled that will be retained after the departure. By using this arrangement of the deployer, the electromagnetic hardware is retained with the host, allowing the same motor and carrier system to be used for successive payloads to be deployed. But because of this architecture, new problems emerge, such as a substantial retained moving mass, an arrest requirement for the sled and a payload transfer problem. These consequences form a part of the design, which is retained, rather than being omitted from the velocity calculation.

![Host manoeuvre, relative release and subsequent propagation. The host establishes its inertial state; commanded release sets payload velocity relative to the host. The resulting orbit follows from the combined state. This is an explanatory schematic, not an orbit-scale drawing.](assets/host_and_release_roles.png){width=100%}

## Research question and approach

The research question is whether a mechanically explicit twelve-payload configuration can provide a low-speed commanded release when its finite motor geometry is retained on the spacecraft while the selected source reference as well as the post-release arrest are evaluated together. The study answers the question through a controlled reference assembly, a defined sequence of custody, numerical force that is calculated and current models, a coupled shot model and structural and mission analyses.

The complete operating cycle of the system analysis is followed. The finite motor force is coupled to the current delivery system, back EMF, source impedance, load resistance and the retained moving mass. The release event causes a change in the mechanical connections between the payload and the carrier, where the carrier stops inside the rail allocation and returns for the next payload. Throughout the transfer, the pallet remains supported by the lift or is positively captured by the carrier. These dependencies are followed by the geometry, source and the motion model.

## Study outcome

The selected Gen5 architecture combines a fixed positive lead-screw feeding mechanism, a vertical indexing and a single captive docking pallet. The power carrier retains that pallet throughout launch, arrest and return. Eight native and STEP states represent the nominal geometry, with the 154 accepted checks supplementing the transfer and release motions. The source-coupled study support commanded cases ranging from 1 m/s to 3 m/s, with the 3 m/s case receiving the full time step audit. The resulting system is a completed computational design reference for a subsequent, future prototype work.

![Gen5 assembly in the frozen home pose. Markers identify (1) fixed storage, (2) indexed lift, (3) retained carrier and pallet, and (4) fixed stator and guide track. All 387 represented CAD objects are present in this CAD-derived render.](assets/ED3_assembly_guide.png){width=100%}

# Objectives and study scope

## Design objectives

The first objective is to define a complete payload path from an individually retained storage cell to free departure. The path must state which element carries and restrains the payload during each transfer. The second objective is to evaluate finite electromagnetic force using the actual winding and magnet arrangement. The third is to couple that force to a stated electrical source and moving-mass model, including the change in dynamics at release and the arrest of the retained carrier. The fourth is to relate release conditions to a host and mission boundary that includes the deployer's installed burden.

| Objective | Implemented method | Reported evidence |
|:--|:--|:--|
| Define repeatable payload custody | Fixed cells, indexed pallet, positive carrier capture | CAD states, lock sequence and motion checks |
| Quantify finite motor force | Cuboid-field Lorentz integral, source-face check, current FEM | Force-position coefficients and numerical comparisons |
| Assess source and shot compatibility | Averaged three-phase current/source model | Release, current, voltage, loss and arrest results |
| Check magnetic loading of carrier | Actual connected-chassis elasticity | Paired face-separation reduction |
| Account for retained burden | Named solid-volume ledger and separate allowance | Dry, loaded and moving-mass totals |
| Assess delivery implications | Common mission boundary and host recoil | Chapter 8 mission analysis |

: Objectives, methods and evidence.

## Reference requirements and interfaces

The reference manifest comprises twelve identical 4 kg rectangular 3U surrogates, each 340.5 × 100 × 100 mm. Dimensions describe the represented contact envelope; compliance with a specific flight spacecraft interface requires a customer ICD [2]. Two six-cell banks provide individually identifiable storage positions. Positive retention must continue through cell opening, transfer, docking, acceleration and controlled release. The rail allocation provides a release station at carrier-aft X1500 mm and 210 mm of post-release arrest travel.

The host is a generic manoeuvring platform. It would provide electrical charging, command and inhibit interfaces, attitude management, structural accommodation and the resources, as needed to execute the mission. A selected launch provider or carrier is outside the definition of reference. This allows the mechanism and the mission calculations to state their assumptions without the implication of any particular vehicle.

## Scope and interpretation

This is a computational design as well as an evaluation study of the spacecraft/deployer. The evidence consists of: native CAD and exchange geometry, analytical calculations, finite-element solutions, coupled simulations and independently conducted numerical checks. The 149.55 kg of dry value is represented by the CAD generated material mass. The 7 kg power/control allowance is additional to it. Neither of them as a manufacturing or weighed mass. The catalog components provide engineering reference data under their documented conditions. They, however, do not establish any vacuum, radiation, lifetime or complete product qualification.

The supported speed range is set to the analysed 1 to 3 m/s commands. The principal 3 m/s case has been reviewed across nominal and adverse assumptions and three inductance values. The scope of this thesis does not assign a robust operating rating at 4 to 4.5 m/s. The 6 m/s case is outside this study. The tolerance allocations, contact laws and thermal properties are stated model inputs; their correlation requires a physical article. No measured VOLLEY prototype performance is reported in any sense. These boundaries apply to every result in this report/thesis.

# Literature review and research contribution

## Conventional deployment and mission control

JAXA’s JEM Small Satellite Orbital Deployer (J-SSOD) and California Polytechnic State University’s CubeSat Design Specification provide relevant context for the payload envelopes, retention, as well as deployment interfaces [1,2]. The need for an agreed contact features and operating boundaries are established by them. Such specifications must be applied at the customer interface. A generic 3U envelope does not replace their detailed requirements.

Differential drag is an established method used for constellation phasing, including working on a Planet spacecraft [3]. It changes its relative motion gradually through differences in ballistic behaviour. A release impulse also changes the relative motion, but it acts at a specific event and requires the host recoil and accounting the payload-interferance accounting. Therefore, a comparison must specify a common delivery objecting with time horizon. A larger deployment speed is useful only in the case where it reduces the resources or meets a delivery requirement that the alternative cannot meet at an acceptable system cost.

## Electromagnetic release and storage mechanisms

The Electromagnetic CubeSat deployment is an established art. Zhao and their colleagues describe a stacked storage system, magnetic transfer with multiple release windows in their 2022 deployer study [4]. Their gravity-compensated laboratory release results include 1 kg dummy speeds of approximately 0.67 to 1.42 m/s and 3 kg speeds of approximately 0.40 to 0.85 m/s for their tested approximate range. Those values are measured results for that mechanism and its test conditions. They provide a useful prior case for test observables rather than a measurement of the present design.

The 2025 high volume storage study describes stack pushing, receiving guides, magnetic capture and transport [5]. Its architecture includes iron patches and spacecraft side grooves. That interface differs from the assumption of a passive rectangular payload. Its approximately 1200 N receiving contact peaks, belong reportedly to zero gravity Simulations. The faster laboratory pushes were gravity assisted. The comparison demonstrates why endpoint arrival, contact force and environmental conditions are to be identified separately when assessing a transport mechanism.

Feng and their colleagues study a higher speed on-orbit electromagnetic launcher and reachable domain [6]. The acceleration, the payload interface and the reachable domain [6}. The acceleration, payload interface and operating regime differ from the present low-speed retained carrier system.] High-speed electromagnetic studies establish context for scaling but does not supply a compatible low-acceleration motor rating. In the case of VOLLEY, the design question concerns the coupled release, custody, source and host burden at the modest commanded speed.

## Finite motors and numerical methods

Halbach&#8217;s permanent-magnet arrangement provides the field-array concept underlying the opposed arrays \[7\]. While a finite winding and finite magnet array introduces longitudinal end effects, a periodic wave is extremely beneficial for its initial sizing. Yamaguchi and Morishita discuss these effects in the Halbach field-magnet linear motors \[8\]. Their relevance here is methodological, the finite geometry must enter the force model at launch and arrest positions.

The present study integrates the Lorentz force over the represented conductors using a finite magnet source. It checks for the active conductor result through an independently implemented source formulation and checks for the current distribution, approximating it through a conduction finite element solution. These comparisons have particular and distinct roles. Agreement between field formulations tests for the implementation of the stated magnet model. A current FEM examines whether the represented conductor pa	th justifies a uniform bar and an approximate return current. Neither the comparisons provide and supply with a physical field or force measurement.

## Contribution of the present study

The contribution is the integration and evaluation of a specific commanded deployment mechanism: twelve fixed 3U cells, a vertically indexed captive pallet, retained moving magnets, passive pre-release keeper opening, source-limited actuation and active post-release arrest. The work provides source-linked geometry, mass and model results for the same reference revision. It establishes what all operating cases can satisfy the declared computational checks and which interfaces require a physical validation. Adjustable electromagnetic ejection, stacked storage and programmable deployment are not claimed as new principles.

# Research methodology and governing models

## Configuration and dependency control

The evaluated fifth-generation design is the configuration used throughout this report. The mechanical capture records the builder & parameter hashes that are used for eight state exports. Each state retains the native part identities, connected solid status, positive volume interference check and the number of physical pallets. From the previous one, the same release geometry creates a separate mass ledger. The electromagnetic source and the structural results can be retained by their input hashes and the method definitions in such a way that the numerical values of them can be traced back to the geometry or data that had produced it.

The sequence of analysis follows physical dependencies: geometry defines contact paths and conductor/magnet positions; geometry and densities define moving mass; force and resistance define electrical demand; source and controller limits define the shot; release changes mechanical connectivity; arrest defines retained-carrier travel; mission calculations use the achieved model release envelope and retained installed mass. Due to this order, the mistaken substitution of one velocity from one configuration, to the mission model of another, can be prevented

## Electromagnetic force and phase convention

For representing the copper volume $V_{Cu}$, the current&#8217;s density $\mathbf J$ and the permanent-magnet field $\mathbf B$, longitudinal force would be

$$F_x(x,I,\phi)=\int_{V_{Cu}}(\mathbf J\times\mathbf B)_x\,dV.$$

The three phase currents are balanced sinusoids and $I$ denotes peak phase current. The position-dependent phase coefficients are combined at their specified electrical phase and the force coefficient therefore has units N per peak phase ampere. Active transverse bars and the longitudinal returns are reported separately because of their differing approximations. Coordinate mapping between field and CAD systems is explicitly recorded: field X is travel, field Y is gap and field Z is depth; CAD uses X travel, Z gap and Y depth.

A source face magnetic charge&#8217;s formulation, independently computes the active force by calculating the numerical integration of the faces of the magnet as well as their exact depth integration. The quadrature refinement distinguishes the effects of numerical integration from the differences in their physical assumptions. The FEM conduction solves the actual connected copper paths and integrates its current density to the permanent magnetic field, at a specific interior station.

![Local motor-force principle. Current and the magnetic field produce Lorentz force on the fixed winding, with an equal and opposite reaction on the moving-magnet carrier. Directions illustrate one local conductor element and the finite model integrates the complete represented geometry.](assets/motor_force_principle.png){width="100%"}

## Coupled electrical and mechanical model

The relationship between the phase voltage, the winding resistance, inductance and back EMF is expressed in terms of a lump electrical description:

$$L\dot I_q=V_q-RI_q-K_e(x)v.$$

The production implementation retains its own balanced three phase conventions and its own source power conversion. The capacitor&#8217;s source is represented by its capacitance and ESR, with the terminal voltage obtained from the Thevenin relation. The requested power must have a feasible physical source root to it. During the regeneration, the terminal voltage is capped to 92.8 V equivalent to 2.9 V/cell in a 32-series arrangement. With the internal capacitor voltage $V_c$, the source resistance $R_s$ and a cap $V_{lim}$, the lower bound of signed source-power is represented as:

$$P_{dc}\geq\frac{V_{lim}(V_c-V_{lim})}{R_s}.$$

This condition prevents the braking command from imposing an excess charging terminal voltage. The positive source power, modulation voltage and phase current have their separate limits. PWM ripple is bounded explicitly around the mean current; transistor switching itself is not resolved.

The moving payload and the carrier interact with one another through a unilateral rear contact. Compressive normal reaction can accelerate the payload and that contact cannot pull it back. First the electrical braking is commanded, and then the mechanical separation occurs when the computed reaction reaches zero. Attached and detached reduced masses are used on the appropriate sides of that event. The same finite motor&#8217;s arrest force map decelerates the retained carrier.

## Energy, numerical verification and structural loading

Mechanical work is evaluated from the signed motor force and relative displacement. Electrical energy is apportioned to mechanical change, copper, inverter, bank and auxiliary terms. An energy residual checks consistency of the time integration and event handling. The independently audited time-step rerun refines the production 20 µs step to 5 µs for all six principal 3 m/s cases and reconstructs the reduced-mass work balance independently. The rerun uses an instrumented copy of the production simulation function; its audit independently checks algebra, source roots, limiting logic and conservation quantities.

The actual connected carrier chassis is solved under opposed magnet attraction. The model assumes linear elasticity with $E=70$ GPa and $\nu=0.33$. Surface integration applies equal inward loads to the two array patches. Six scalar constraints on three noncollinear web nodes remove rigid-body modes. Paired face closure is evaluated at common XY positions, which eliminates the arbitrary rigid displacement gauge from the gap comparison.

## Mission mechanics

For a payload released with relative velocity $\mathbf u$ from a closed host–payload system of pre-release mass $M$ and payload mass $m_p$, momentum conservation gives

$$\mathbf v_p=\mathbf v_0+(1-m_p/M)\mathbf u,\qquad
\mathbf v_h=\mathbf v_0-(m_p/M)\mathbf u.$$

Here $\mathbf u$ is the payload-to-retained-host relative velocity after carrier arrest and return. For the current 4 kg payload, retained sled mass $m_s=13.128$ kg and modeled sled-to-host release speed $V$, the scalar separation mapping is

$$u=V\frac{M-m_p-m_s}{M-m_p},\qquad \Delta v_p=V\frac{M-m_p-m_s}{M}.$$

Full-precision carrier mass is retained in the numerical inputs. The final retained-host recoil after carrier arrest must be distinguished from its transient reaction during carrier acceleration. At release, the payload orbital energy is $\epsilon=\|\mathbf v_p\|^2/2-\mu/r$ and its osculating semimajor axis is $a=-\mu/(2\epsilon)$. These identities describe the immediate orbital change. Finite-duration host manoeuvres, perturbations and a common terminal epoch are required to compare actual delivery campaigns [9].

# Controlled Gen5 configuration

## Architecture and dimensional definition

The controlled assembly comprises two fixed banks, each integrating six dedicated 3U cells, alongside a vertical indexing cradle and the launch rail. Each bank utilises guided positive pushers to translate a selected spacecraft toward the central pallet. The lift mechanism supports the pallet, the X end frames, and the independently retracting Y keepers. The central cassette corridor extends to 100 mm bilaterally from Y0 and maintains a continuous nominal end-frame clearance of 0.5 mm from both the represented payload and the relevant carrier corner hardware.

The retained carrier uses 16 mm plates and a 20 mm negative-side web. Each of its arrays has 42 separate magnets spaced 8 mm apart. The stator has 216 bars, linked into three actual phase paths with return necks of at least 21 mm². The motor is iron-less, in the stated field model. Support perturbations and conductor reaction are not included in the permanent-field approximation.

| Reference item | Selected definition |
|:--|:--|
| Payload capacity | Twelve 4 kg, 340.5 × 100 × 100 mm 3U surrogates |
| Storage | Two fixed banks, six dedicated cells per bank |
| Transfer | Guided positive pushers and Z-indexed captive pallet |
| Pallet | One physical item, retained on the carrier during the shot |
| Release station | Carrier aft X1500 mm; relative powered stroke approximately 1.3 m |
| Keeper opening | Passive 12 mm opening over aft X1445–1495 mm |
| Arrest allocation | 210 mm following release |
| Return | Powered LSM return to the home interface |
| Rail endpoint | 2250 mm |

: Gen5 reference definition.

### Guided positive feed

The selected cell use a lead-screw driven pusher, along with two guide shafts. The screw gives a slow positive displacement, while the fixed cell restraints and the receiving interface gets custody. The drive components are represented by their catalog reference envelopes and their inclusion in CAD does not clear its manufactured performance or vacuum life.

![Selected south-bank level-5 guided-feed subassembly. Numbered targets identify the lead-screw reference, motor/gear and brake envelopes, pusher frame and guide shaft. The payload envelope and fixed channel frame are hidden for access; the accepted hardware geometry and pose are unchanged.](assets/feeder_detail_annotated.png){width=100%}

## Pallet docking and positive custody

The pallet includes a Y0 crossbar, interleaved payload contact pads, four 8 mm feet and two outboard lift-grip interfaces. Its feet land on the carrier top Z30 while the payload contact surfaces remain at Z46. During the landing, its lift pins remain engaged. The upper carrier capture caps then close and their independent lock pins are engaged. Two pallet lock shafts insert by 12 mm and rotate their 12 × 4 mm heads through 90 degrees, retaining the pallet in Z.

Only after the carrier capture is established do the overhead Y keepers open and the lift grips retract by 26 mm. The lift then rises clear of the launch path and the reverse custody sequence retrieves the pallet after carrier return and home indexing. This arrangement uses one shared pallet throughout the entire operating cycle, avoiding an unaccounted second carrier or any unsupported transfer between the nominal poses.

The pallet lock shafts are 6 mm in 6.2 mm web bores at carrier-local X40 and X468, Y−90, to a significant degree; their heads stow at Z32-35, below the pallet underside Z38, and capture at Z44-47, which is why any separate 6 mm home-index pin interface must, in this setting, withdraw before translation, on the whole. In parallel with this, diverse functions are therefore ran by the lock sequence and home index and distinctly block.

![Pallet handoff and carrier lock arrangement. The lift grips retain custody until the carrier locks capture the pallet.](assets/02_handoff_pallet_locks.png){width="100%"}

## Feed, launch, release and recovery

A nominal cycle begins with an empty carrier indexed at home and the pallet acquired by the lift. The lift indexes to a selected cell, the relevant cell restraint opens under the permitted state, and the guided pusher transfers the payload to the pallet. The receiving end frames and keepers establish the containment. After cell closure and when the pusher gets retracted, the lift returns to the carrier and completes the entire docking sequence.

For the launch, all lift hardware is cleared and the pallet locks are engaged. The home pin is withdrawn and host & source conditions permit actuation. The motor then accelerates the carrier and payload together along the rail. The spring-closed forekeepers encounter fixed 50 mm ramps from the carrier-aft X1445 mm and complete their 12 mm opening at X1495 mm. The open inner edges of this lie at \|Y\|54 mm, giving it a 4 mm side clearance around the nominal payload. Rounded followers and a 5 N preload, 0.5 N/mm spring reference make the opening a finite mechanical motion before release.

The electrical braking reduces a rear-contact reaction until it reaches zero. The payload then departs along its free path. The forward pallet grip ears are trimmed to Z45.5, 0.5 mm below the payload flight plane. The carrier and the pallet remain on the rail, arrest under LSM control and return under power. At the allocated arrest endpoint, their forward extent is X2224.5 mm, within a 2250 mm rail. No auxiliary eddy-current brake force has been credited in this selected architecture.

![A captured payload is seen at the source level before it is transferred to the launch plane. The image shows the selected fixed bank as well as the indexed pallet arrangement.](assets/03_captured_source_level.png){width="100%"}

![A payload being transferred from a retained cell to the carrier. The guided pusher feeds the lift held pallet, the lift then indexes and docks it, and finally the carrier capture is established before the lift release. This functional schematic is not to scale.](assets/payload_transfer_sequence.png){width="100%"}

## Sequencing and inhibits

The operating sequence requires an agreement between the mechanical custody and command state. A command to release the storage restraint is valid only if the receiver is correctly indexed and available. The lift grips withdraw only after carrier capture. Translation requires the lift, locks and home-index hardware to be in their permitted states, with the launch path clear. Host manoeuvres are inhibited during operations that require quiescent host conditions.

The interlock state model exercise contains 24 accepted nominal commands and 166 passing tests that cover declared faults including power loss, jam, sensor disagreement, timeout and a host-burn conflict. These tests reinforce the logic encoded in that model. Their engineering value is in making an unsafe transition explicit. They do not represent the hardware reliability, sensor reliability, autonomous fault recovery, integrated control hardware.

# Electromagnetic drive, power and control analysis

## Finite field and force results

The finite source model of the system uses 42 magnets per array with 8 mm block pitch and 48 mm wavelength. It assumes 1.32 T polarization. At the launch interior, the optimized active force coefficient is approximately 1.328 N/A. Adding the represented returns to it gives approximately 1.399 N/A. The active coefficient varies little through the 0 to 1.3 m launch stroke, while the end geometry becomes more influential in the later arrest region. Therefore, the arrest uses its own position dependent map rather than an extrapolated constant force.

At displacements 0, 0.65 and 1.3 m, the increase in force quadrature changes the active coefficient by an approx. 0.100 to 0.110%. The source formulation reproduces the same active-conductor values with the relative differences being below $10^{-12}$ at its refined face order. That agreement is strong implementation evidence for the shared finite-magnet suppositions and is not another statement of material nor a physical exactness at that precision, in the actual application.

![The finite motor&#8217;s force coefficients from the actual magnet and winding geometry are represented here. The active bars and the represented return contribution are distinguished.](assets/finite_force_coefficient.png){width="100%"}

## Current distribution and inductance

The three phase conductors are modeled as the conduction finite element domain of these three conductors. The force integration based on resulting current density at the fixed 0.65 m station is 1.396651 N/peak phase ampere and the uniform bars and approximate returns is 1.399055 N/A. This difference of −0.1718% favors the simpler current representation for this interior station. Does not include a complete position map, redistribution of AC current, detailed harness or magnetic effects caused by supports.

The study of winding inductance is with regularized current centrelines to the rectangular conductors, and the effects of mutual inductance have been taken into account. For the provided cases, the Effective Inductance is estimated to be about 4.50 - 5.82 μH with the help of refinement: and with the help of radius sensitivity. The coupled model is then considered to be sensitive in a wide range, which includes 3, 20 and 100 µH. The values are also higher, which reveal a trade-off between a lower switching ripple and slower current decay when released. No measured winding or harness inductance is assumed.

## Selected source and switching reference

Eaton 64 TV1860-3R0107-R family cells are used in a 32S2P power architecture \[10\] in the power reference. Initial Charge Command is 2.7 V per cell (86.4 V). Bank Capacitance nominal is 6.25 F, ESR represented is 0.176 Ω. The adverse ageing sensitivity is: 3.9375 F and 0.352 Ω. The capacitor is not represented as an ideal voltage source; these source parameters are used in the shot model.

The switching reference is one three half-bridge inverter with 10 IRFP4668 devices per switch position, 60 devices in total \[11\]. The reference PWM frequency = 40 kHz. UCC21520 isolated dual-output drivers provide the gate-drive reference, with thirty drivers allocated and individual gate resistors \[12\]. Main features of the model are hot resistance and a 25% device-sharing factor, declared commutation-loop inductance and a switching-time allocation. Those assumptions of circuit design with catalog checks, need layout and thermal correlation.

Regenerative power is also restricted to limit the terminal-cell voltage to no more than 2.9 V when braking. This control constraint is apart from the 3 V catalog working-voltage rating. The selected limit leaves a margin to that catalog value while retaining a feasible source solution. The independent review ensures that 0 requested q voltage is possible at limited steps and that the actual modulation is lower than the SVPWM ceiling limit.

## Principal 3 m/s coupled result

The main release is 3 m/s. All six combinations of nominal and adverse assumptions are checked in conjunction with the declared stop inside the allocation (210 mm) and satisfy the release, phase-current, device-current, voltage, source and energy checks – regardless of whether the inductance is 3, 20 or 100 µH.

| Case | $L$ / µH | Absolute stop travel / m | Peak mean phase current / A | Peak cell voltage / V |
|:--|--:|--:|--:|--:|
| Nominal | 3 | 1.507288637 | 248.717 | 2.700000 |
| Nominal | 20 | 1.507288637 | 248.717 | 2.725424 |
| Nominal | 100 | 1.507288964 | 249.246 | 2.798825 |
| Adverse | 3 | 1.507333466 | 423.129 | 2.700000 |
| Adverse | 20 | 1.507333468 | 423.132 | 2.899987 |
| Adverse | 100 | 1.507278013 | 420.040 | 2.900000 |

: Audited 5 µs time-step rerun of the six principal 3 m/s cases. Travel is measured from the launch model origin while the release occurs near 1.3 m, leaving approximately 0.2073 m of arrest travel.

The change of 20 µs to 5 µs only changes the stop position by at most 0.000670 mm and the peak mean current by at most 0.0703 A. Average signed motor work is in agreement with separately constructed reduced-mass kinetic-energy change and friction to within $6.3\times10^{-12}$ J. The maximum total electrical energy residual is 0.00247 J. The actual highest modulation is 0.958316 of the theoretical Maximum SVPWM ceiling. These comparisons help to ensure the numerical consistency of the simulated model and the assignment of events.

![Carrier-to-host relative speed during nominal 1, 2 and 3 m/s command cases at 20 µH. The plotted histories include the launch and the carrier arrest. 1 and 2 m/s histories are production model replays. The principal 3 m/s case also has a six case time-step audit described.](assets/commanded_release_traces.png){width="100%"}

![The energy account for the principal nominal at 3 m/s, 20µH. The signed source energy, mechanical change and the dissipative terms are taken from the coupled source output and the declared accounting boundary is retained.](assets/shot_energy_account.png){width="100%"}

The declared checks of the production model are also met by the 1 and 2 m/s source cases. They provide a range of 1–3 m/s and the full audit for a time-step applies to the 3 m/s cases. The impressive range mentioned in the source study is not sufficient to justify the extension of the good range above 3 m/s.

# CAD integration, packaging and installed mass

## Native geometry and state verification

Eight positions are described for the case of controlled native/STEP: home, captured, lower, handoff, withdrawn, clear, release and arrest. The native part count is 387 in the loaded states and 386 at arrest after the payload departs; the carrier and pallet remain on the rail. One physical pallet has been selected for each selected state. The archived filename withdrawn refers to the withdrawal of the lift grip pins, the selected mechanism lacks the pallet drive to move in the horizontal direction.

The typical form of inter-motion is assessed by the original/ final refinement. This set includes 135 selected baseline poses and 19 selected final direct checks, resulting in a total of 154. Finally, the refinement shows that the pallet changes are a strict material subset that uses that rationale, that the closed-lock geometry remains identical across the compared revisions, and a restored &#8216;web material&#39; passes a conservative &#8216;carrier-travel envelope&#39;. The selected poses and these geometric proofs complement each other and provide support for the represented motion sequence.

The eight states passed their claimed connected-solid, interference and pallet-count tests. These results indicate nominal geometric compatibility of parts represented. A visual assembly check is not as informative as the individual shapes and exact-solid intersections, as small local clearances are hidden in such an isometric view in the keeper, lock and grip motions.

![The carrier docked with the lift being clear. This arrangement is before the home index is withdrawn and motion is commanded, launch-ready custody.](assets/04_clear_docked.png){width="100%"}

## Actual carrier stiffness under magnetic attraction

The structural model is actually based on the real connected chassis with 6.2 mm pallet-lock shaft bores, axle bores, home lug and integral supports. The BREP identity is identical to the one used for the final CAD source. The 336 × 90 mm load patches each receive 3010.481 N inward. Their resultant force and moment cancel out. The accepted mesh has 112519 nodes and 62198 quadratic tetrahedral elements with a minimum scaled Jacobian of 0.075419.

Relative equilibrium residuals in CalculiX are around $1.42\times10^{-12}$ and $1.47\times10^{-12}$, when applied to force and moment scales, respectively. Interpolation with paired displacement over 9,969 common sample locations at XY results in the highest face separation reduction of 0.285983 mm. A 1.3 load multiplier applied to the same linear solution gives a closure of 0.371778 mm. From the sum of two nominal 1 mm gaps, the remaining summed gaps are 1.714017 mm at nominal load and 1.628222 mm at 1.3 times the load.

| Quantity | Nominal load | Declared 1.3× sensitivity |
|:--|--:|--:|
| Attraction on each array / N | 3010.481 | 3913.625 |
| Maximum paired closure / mm | 0.285983 | 0.371778 |
| Remaining summed nominal gaps / mm | 1.714017 | 1.628222 |

: Actual connected-chassis linear-elastic result. The multiplier is a load sensitivity of the same solution, not an independent solve or a statistical bound.

![Actual carrier mesh and paired gap closure, depicted under opposed array loading. For the case of visualisation, the displacement has been enlarged.](assets/ACTUAL_CHASSIS_RESULT.png){width="100%"}

The positive sum of the gaps forms a beneficial structural comparison in the context of the given load and support model. It does not demonstrate that all gaps between the segments are positive because the local clearance also depends on how the individual segments are aligned, the compliance of the segment supports, the position of the rollers and the behaviour of the joints. Those amounts are scattered in the tolerance budget and prototype verification approach listed below.

### Matched ANSYS static cross-check

A correct ANSYS static package provides a second-solver check of the same bare-chassis boundary \[21\]. The reference BREP you are provided with has no two-way Boolean volume difference to the selected chassis. The independent audit reconstructs the opposed patch resultants at centroids (444, 0, ±14) mm at the level of 3010.480631 N; the same $E=70$ GPa, $\nu=0.33$ and six scalar 3-2-1 constraints are assumed. This comparison does not add assembled stator, roller, contact or host-support stiffness.

| Solver / mesh | Nodes | Elements | Peak closure / mm | Difference from reference / % |
|:--|--:|--:|--:|--:|
| CalculiX reference | 112519 | 62198 | 0.285983 | — |
| ANSYS h5.5 | 59677 | 31470 | 0.285241 | −0.260 |
| ANSYS h4.5, primary | 81355 | 43563 | 0.286392 | +0.143 |
| ANSYS h4.0 | 98542 | 53210 | 0.287589 | +0.562 |

: Matched-load bare-chassis paired-closure comparison. The three ANSYS meshes provide a sensitivity screen rather than a formal asymptotic convergence or error guarantee.

This is the main native RST which was read separately and evaluated at common XY positions using a separately coded quadratic-face interpolator. 11,448 delivered closure samples repeat within $5.0\times10^{-11}$ mm. The primary sampled maximum is 0.286391914 mm near (446, 45) mm, 0.142863% above the 0.285983350 mm CalculiX reference. The peak changes by 0.404% and 0.418% for successive refinements of the model; the total span of the three meshes is 0.002349 mm. Used to derive an agreement with numbers under the assumptions of matched load and restraint.

![The corrected ANSYS generated primary paired-closure field and profile at the Y45 mm patch boundary, compared against the CalculiX reference. This graph uses native result-derived data, not a Mechanical GUI screenshot or physical measurement.](assets/chassis_paired_closure.png){width="100%"}

The source budget explicitly uses $g_{\mathrm{face}}=1-1.3d/2-(0.20+0.15+0.15+0.05)$ in millimetres, where $d$ is nominal paired closure. The fact that its factor of one half is stated under the interpretation of the centre, it is not deduced from the agreements of the solvers. Using the same conditional formula on the primary ANSYS peak, we get 0.263845 mm, and on the finest-mesh peak, 0.263067 mm with the existing reference allocation of 0.264111 mm. The latter replacement decreases the allocation by 0.001044 mm (1.044 µm). This reflects the cross-check sensitivity without revising the upstream budget or establishing either actual assembled gap. The input and the arithmetic are both saved in evidence/ansys/CLEARANCE_SENSITIVITY.json.

The allocation of existing sensitivity and individual face placed below is still based on the above mentioned reference solution in CalculiX. The solver comparison does not provide a new assembled-gap warranty, or strength margin. Native project GUI reopening, modal shape identity and hardware qualification are outside the accepted static comparison.

## Mass accounting and system burden

The native ledger stores properties of the material, such as represented properties, and records, names a part identity, mass, CG and inertia. The 48 kg is exactly matched by the prescribed surrogate masses from 12 payloads. The dry is 149.557 kg and the loaded assembly is 197.557 kg. The sled hardware and without the pallet weigh 12.781kg, the pallet weighs 0.347kg, making the retained moving mass for the shot model 13.128kg.

| Accounting boundary | Mass / kg |
|:--|--:|
| Dry represented CAD assembly | 149.557 |
| Twelve payload surrogates | 48.000000 |
| Loaded represented CAD assembly | 197.557 |
| Separate power/control allowance | 7.000000 |
| Dry study mass including allowance | 156.557 |
| Loaded study mass including allowance | 204.557 |
| Retained moving sled plus pallet | 13.128 |

: Mass boundaries used in the current study. The power/control allowance is explicit and additional to the represented material mass.

The 13.046 kg per payload is derived from the dry represented mass of 12.463 kg per carried load and an allowance of 7 kg of the entire system. These divisions are an allocated burden of the system and not the mass of canisters. The following lists the 7 kg power/control allowance. These allocations go into the host mass; and these allocations are non-spatial in the CAD CG/inertia.

| Electrical/control item | Mass / kg | Basis |
|:--|--:|:--|
| 64 capacitor cells | 1.280 | 64 ×20g catalog typical |
| Cell cage | 0.420 | design allocation |
| Balancing and protection | 0.200 | design allocation |
| 60 MOSFET packages | 0.360 | package mass allocation |
| 30 driver packages | 0.012 | package mass allocation |
| Boards and local interconnect | 0.700 | design allocation |
| Thermal plate | 0.900 | design allocation |
| DC-link capacitors | 0.500 | design allocation |
| Charger | 0.500 | design allocation |
| Controls and encoders | 0.600 | design allocation |
| Harness and bus | 0.800 | design allocation |
| Fasteners and support | 0.600 | design allocation |
| Mass reserve | 0.128 | allocation |

: Explicit electrical/control allowance. Only the bare-cell mass is catalog-typical; the other entries are design allocations.

They explain that there will be large amounts of hardware that remain in place when using controlled release. A mass advantage for this deployment over conventional spring deployment is not formed from this study.

## Feed and lift sizing

The pusher moving mass is 0.201 kg; with the selected 4 kg payload it is 4.201 kg, below the feed-sizing assumption of 7.5 kg. Transfer size is 250 mm, using a 40 s quintic rest-to-rest command, 11.71875 mm/s peak speed and 3164 rpm peak motor speed. The stated resistance cases of 25–155 N satisfy the catalog torque/speed and screw-buckling screens.

The moving lift is made of 3.226 kg cradle structure, 0.347 kg pallet and 4 kg payload, which total to 7.573 kg. This is below the 10 kg lowest lift-sizing case. The mechanically synchronized twin-screw reference travels 784 mm in 120 seconds, has a screw lead of 4 mm, a 3242G024BX4 motor with nominal 20:1 32GPT gearing \[14\]. The 10 kg coast cases for 50 & 100 N resistance meet the torque/speed and &#8220;equal-share&#8221; buckling screens as required. The sizing record is not shortened and still recognizes larger mass and ground gravity sensitivities.

## Clearance and differential-expansion budgets

Initial allocation for magnetic-face alignment-plus the actual-chassis closure result at the 1.3 load multiplier is incorporated into the magnetic-face clearance budget. The closing distance of the two is 0.371778 mm and the stated centred split uses 0.185889 mm per face. There is also an additional provision of 0.20 mm for guide centring, 0.15 mm for surface flatness, and 0.15 mm for assembly along with an allowance for differential thermal movement of 0.05 mm. These allocations leave 0.264111 mm as a conditional minimum individual-face design budget, with each nominal face gap being 1 mm.

The end-frame clearance of 0.5 mm is tested with a hard datum stack. Machining and docking repeatability are allocated 0.1 mm each. The calculation is performed over the payload length of 340.5 mm with the assumed differential expansion coefficient of 12 µm/(m·K) and shows positive residual clearance for the whole payload range of differential temperature (i.e., 0 to 60 K).

| Differential temperature / K | Thermal movement / mm | End-frame rigid-stack residual / mm |
|:--|--:|--:|
| 0 | 0.00000 | 0.30000 |
| 20 | 0.08172 | 0.21828 |
| 40 | 0.16344 | 0.13656 |
| 60 | 0.24516 | 0.05484 |

: End frame clearance sensitivity of rigid datums (based on 0.5mm nominal and two 0.1mm tolerances)

There is a guide sensitivity analysis of the side-clearance residual of 0.925554 mm for transverse load of 100 N. The manufacturing sensitivity is 0.3 mm, and the yaw and thermal sensitivities are 0.297143 mm and 0.096 mm, respectively.

These constitute a class of budgets, which describe the allowable dimensional requirements of the physical article. This carries through to the declared tolerance stack; and the limits on the correlation to physical hardware are dealt with in chapter 10.

## Copper pulse and repeated-operation thermal budget

Copper is actually used in the actual conducting meshes to the extent of 11.061 kg. The calculation of the pulse is based on the conservative squared-current integral as provided by the source model, along with the conductor-current field, with a density of 8960 kg/m³, heat capacity of 385 J/(kg·K), thermal conductivity of 400 W/(m·K) and resistivity at 20 °C of $1.7\times10^{-8}$ Ω·m. The bulk temperature rise is based on $\Delta T_b=Q_{Cu}/(m_{Cu}c_p)$. The local adiabatic approximation is based on

$$\Delta T_{local}=\frac{\rho_e}{\rho_m c_p}\int J^2\,dt.$$

The maximum bulk copper temperature rise per pulse in all eighteen nominal/adverse cases with a range of speed from 1–3 m/s and considered range of inductance values is 0.066668 K. The adiabatic temperature rise estimate is 2.495038 K from the maximum current density element, compared to the volume-99 as calculated, 0.758373 K. The different values differentiate bulk heating, local estimate which covers 99% of the volume and mesh-corner maximum.

For the repeated-operation calculation, a diffusion length of 90 mm yields a characteristic diffusion time of 69.8544 s vs a reference interval of 450 s between shots. For twelve worst case pulses, with no external cooling credited, the bulk upper rise is 0.800015 K. Adding one local pulse observation gives a 3.295053 K local recovery estimate under the repeated-cell diffusion assumption. This calculation covers conductor heating; capacitor, switch, driver and mounting temperatures require separate hardware assessment.

| Thermal quantity | Current computed value |
|:--|--:|
| Copper mass from actual conductor meshes / kg | 11.061 |
| Maximum supported-case bulk rise / K per pulse | 0.066668 |
| Volume-99 local adiabatic rise / K per pulse | 0.758373 |
| Mesh-maximum local adiabatic observation / K per pulse | 2.495038 |
| Twelve-pulse bulk rise without external cooling / K | 0.800015 |
| Bulk accumulation plus one local pulse estimate / K | 3.295053 |

: Conductor thermal budget – source coupled current cases with actual conduction current field.

## Payload compliance and feed capture

The largest payload axial normal reaction in the supported shot cases is 26.863497 N. A declared payload surrogate uses four aluminium rails of 8 × 8 mm cross-section and 340.5 mm length, with $E=70$ GPa, together with the stated rear-pad compliance. The effective four-rail axial stiffness is 51.817 MN/m and stored elastic energy is 6.9634 µJ. If all of that energy were converted to rotation about a selected axis, the limiting rate follows $\omega=\sqrt{2U/I}$.

For the 4-rail stored energy model, the payload surrogate&#39;s pitch/yaw inertia is 0.0419801 kg·m² and has an angular-rate bound of 1.04359°/s. If the smallest of the 3 principal inertias is taken as 0.00666667 kg·m², a more conservative bound along all axes of 2.61876°/s is achieved. Lower load sharing results in higher elastic energy stores and hence in larger bounds of the angular-rate.

| Active reference rails | Effective stiffness / MN/m | Pitch/yaw energy bound / °/s | All-axis energy bound / °/s |
|:--|--:|--:|--:|
| 1 | 12.954 | 2.08717 | 5.23751 |
| 2 | 25.908 | 1.47585 | 3.70348 |
| 4 | 51.817 | 1.04359 | 2.61876 |

: The compliance-energy sensitivity for the declared surrogate is presented in this table. The calculated angular rates are energy-derived upper bounds on angular rate, not predicted angular-rate histories.

The nominal feed-capture computation is based on the assumed free 4kg load – at maximum commanded pusher velocity of 11.71875 mm/s. Its kinetic energy is 0.000274658 J. In the simple elastic model, it is estimated to impart an elastic deflection of 0.434927 mm to two 3 mm steel keeper cantilevers with an effective length of 118 mm and a total peak force of 1.26301N. The calculation here gives a receiving-energy scale without assuming that the pusher grips and slows the payload.

# Orbital mechanics and matched mission comparison

## Effect of the supported release range

When the orbital energy of the satellite is changed by a low velocity tangential release, this changes the previously determined orbital period of that satellite. If the velocity at an initially circular orbit is increased by a small amount, the first order approximation is $\Delta a\approx2a\Delta v/v_{orb}$. A payload inertial velocity increment of 1–3 m/s in the orbit of, say 450 km altitude, at an orbital velocity of around 7.64 km/s, will yield a change in semimajor axis of about 1.8 – 5.4 km. This is a local value only and will vary with release recoil and the commanded mission direction in each case.

The analysis of the host response shall be part of the release analysis. A nominal relative separation speed of 3 m/s in the principal shot gives a payload inertial increment of approximately 2.927 m/s. The difference, 3 − 2.927 ≈ 0.073 m/s, is the magnitude of the transient rest-of-host recoil in the opposite direction, using the 687.429 kg rest-of-host reference. During this transient recoil response, both the host system and the carrier system accelerate, and subsequent arrest transfers carrier momentum back to the retained host/deployer system. It is important, thus, to use the proper conserved release state for the mission propagator and account for the mass retained by the complete host/deployer system after deployment, rather than considering the entire carrier motion as a delivery impulse of the payload.

## Common mission boundary

The terminal epoch, host base mass, propulsion and force ceiling are identical for each delivery option. Each option is given the same target position and velocity states, while the same payload manifest is used for both. The traditional approach is to use spring separation and host manoeuvres, while the VOLLEY option has a supported release state followed by host manoeuvres. Each case includes consideration for the mass of the device, payload removal at each release, recoil, and propellant use and protection of guard intervals before and after release.

The comparison considers the propellant consumption, peak thrust, scheduling and installed system burden when the release velocity is controllable. It does not require that indexed feeding has the same handling time as spring deployment. Therefore, Manoeuvre windows are defined separately in each case. The evaluation of geometric compatibility and electrical-source requirements is done separately from scheduling requirements.

## Current matched-state campaign

Here, the matched mission study builds two different mission families (architecture independent) for the common nominal sun-synchronous Earth-orbit (500 km) in the fixed-axis J2 gravity environment. The position/velocity of a payload is obtained from the inertial along-track velocity increment that is added to the chief state at each scheduled release. The time evolved states are then fed forward to a shared terminal time. The 12 payloads belonging to each family have the same deltaVi of 2 m/s and the other 12 payloads belong to a family with the same deltaVi that alternates between 1 m/s and 3 m/s. These simulated targets provide a repeatable delivery comparison within the supported release range.

The host begins at 500 kg wet mass, comprising 480 kg dry bus and 20 kg propellant. Adding 48 kg of payload and the 156.557 kg VOLLEY study device gives 704.557 kg initial system mass. The spring reference uses a declared 72 kg device-class assumption, giving 620 kg initial system mass. Specific impulse is 220 s and host-force ceilings are 1 and 5 N. The current VOLLEY dry-device penalty is therefore 84.557 kg at this comparison boundary.

Twelve releases occur at 450 s intervals from 450 to 5400 s. The common terminal epoch is 91800 s, or 24 hours after the last release. Both architectures have 5 s pre-release and 20 s post-release zero-force guards. VOLLEY requires a 400 s loading coast, consisting of a declared 355 s cycle and 45 s reserve. Spring policies can use either the shared narrow manoeuvre windows or wider windows; the wider candidates allocate 35% or 45% of a transfer leg to each of two manoeuvre intervals. They do not inherit VOLLEY's loading-coast requirement.

The conventional comparison includes a fixed 2 m/s midpoint separation class and an ideal per-payload pretrimmed spring policy. Pretrim compensates predictable finite-host recoil through separation energy selected before the campaign; it does not provide in-flight retasking. VOLLEY release states are calibrated from the current source-coupled outputs, with the retained carrier mass mapped through the conserved payload/host event. All fourteen targeted candidate policies close their position/velocity equations, after which force and propellant bounds determine which candidates are admissible.

| Target family | Host ceiling / N | Release policy | Propellant / kg | Peak force / N |
|:--|--:|:--|--:|--:|
| Uniform 2 m/s | 1 or 5 | VOLLEY | 0.0524 | 0.677827 |
| Uniform 2 m/s | 1 or 5 | Fixed-2 spring | 0.0470 | 0.656269 |
| Uniform 2 m/s | 1 or 5 | Pretrim spring | 0.0524 | 0.677826 |
| Alternating 1/3 m/s | 1 | Pretrim spring, wider windows | 0.0750 | 0.184432 |
| Alternating 1/3 m/s | 5 | VOLLEY | 0.2899 | 4.204212 |
| Alternating 1/3 m/s | 5 | Pretrim spring, shared windows | 0.0536 | 1.016738 |

: Lowest-propellant tested candidates within each stated host-force ceiling. Device masses are 156.557 kg for VOLLEY and a declared 72 kg spring-class assumption. “Pretrim” is an ideal preplanned separation-energy benchmark.

For the alternating family, no tested VOLLEY or fixed-2 spring candidate meets the 1 N ceiling. VOLLEY meets the 5 N ceiling; the lowest tested fixed-2 spring peak is 7.537264 N, above both declared ceilings. This is a bounded result for the sampled two-window policies. It does not establish global infeasibility of spring-assisted delivery, as the ideal pretrim policy demonstrates by closing at both force ceilings.

The nine Orekit replay jobs were finished, including six bounded nominal, one above ceiling diagnostic, and two step refinement jobs. All of the declared consistency checks were numerical checks and passed. The differences in the target&#39;s position and velocity, respectively, did not exceed 11.247 µm and $1.235\times10^{-8}$ m/s. Both the independent mass-flow and independent momentum residuals were kept under $1.26\times10^{-12}$ kg and $1.05\times10^{-9}$ kg·m/s respectively. Both of the VOLLEY checkpoints moved a maximum of ±12.178 µm when the native maximum integration step was lowered from 60 s to 30 s. The numbers represent the differences between the results of the replay utilizing the outlined J2 model.

![Current common-epoch mission resource comparison. Target families, device masses and host-force ceilings are stated in the text; spring policies include an ideal pretrim benchmark.](assets/MISSION_RESOURCES.png){width=100%}

## Result of the comparison

The uniform target family gives closely similar propellant demand for VOLLEY and ideal pretrim spring deployment, with the fixed-2 reference slightly lower in the sampled policies. In the alternating family, the 5 N VOLLEY candidate uses 0.2899 kg, compared with 0.0536 kg for ideal pretrim spring deployment. VOLLEY therefore establishes neither a propellant-use nor a mass advantage over this ideal benchmark.

The distinctive capability demonstrated by the configured mechanism is commanded 1–3 m/s release with a shared retained motor and carrier. The pretrim spring benchmark assigns separation energy in advance. A future mission that values in-flight changes to the release plan must state that requirement and compare the cost of supplying it by each alternative. The current synthetic target study makes that distinction visible while retaining the dry-device burden and fair conventional benchmarks.

## Interpretation for a manoeuvring host

A commanded release impulse can reduce the host manoeuvre required for delivery of a specified payload state. But this benefit should be weighed against the electrical, attitude control and handling resources needed to use a device, as well as the dry weight. A decrease in the amount of propulsion required does not prove improvement in the amount of delivered service or reduction in total launch mass. Conclusions are therefore dependent upon the payload manifest chosen and using equivalent system boundaries for the comparison.

The most current reference is relevant for hosts able to manage repeated deployments and afterwards taking up on manoeuvres. If a payload needs only separation clearance from an already suitable orbit, the mission provides fewer opportunities to take advantage of variable release velocity. It is therefore straightforward to treat the value of the mission here to be dependent on the target states from which it comes, and resources that it might have available, while the design of the mechanism and its operating envelope are exposed as a set of engineering results.

# Results and engineering discussion

## Integrated computational findings

The overall result is a combined study on the low speed mechanisms, where the payload handling, finite size of motor, mass of the moving parts, and the supply of electric power, combined with the need to arrest the carrier after payload release, are all considered in one reference design. There are eight released CAD states and 154 accepted motion and refinement checks for nominal CAD compatibility. The retained pallet resolves the custody transfer because it stays with the carrier all the way to the shot and back. These passive forekeeper cams produce a finite opening motion before payload release.

The predicted active force coefficient by EM is about 1.328 N/A; including the represented returns gives 1.399 N/A. The implementation of the active-force is also checked separately, with a source-face calculation. At one inside station the current-density finite-element model differs by 0.172% from the uniform-current result. This is a local numerical comparison. These coefficients restrict the claims that are possible for their source coupling nature. The 6 cases audited at 3 m/s are at the upper end of the range (1–3 m/s) studied and meet the stated checks.

| Evaluation | Current outcome | Meaning |
|:--|:--|:--|
| Released CAD states | Eight pass | Nominal represented configurations are compatible |
| Motion and refinement | 154 accepted checks | Sampled paths and stated subset/envelope proofs support the sequence |
| Independent active-force formulation | Agrees at checked stations | Finite source implementation corroborated under shared assumptions |
| Actual conductor-current force | −0.172% at checked station | Local current-distribution approximation is supported |
| Principal source-coupled case | Six 3 m/s cases pass at 5 µs | Averaged electrical/release/arrest model satisfies declared criteria |
| Actual chassis paired closure | 0.286 mm; 0.372 mm at 1.3× | Opposed-load elastic closure remains below summed nominal gaps |
| Individual magnetic-face budget | 0.264111 mm | Declared centring/flatness/assembly/thermal allocations remain positive |
| Copper thermal budget | 0.066668 K bulk per pulse; 3.295053 K repeated local estimate | Current-field pulse and declared diffusion assumptions characterize conductor heating |
| Four-rail contact-energy bounds | 1.04359°/s pitch/yaw; 2.61876°/s all-axis | Declared surrogate compliance bounds rotational energy |
| Represented dry burden | 149.557 kg plus 7 kg allowance | No installed-mass advantage established |

: Summary of the current Computational Results and their engineering implications.

## Why arrest and custody govern the design

The acceleration of the payload stops but once released it continues moving. This is the scale for the isolated kinetic energy: at 3 m/s the 13.128 kg carrier has an isolated kinetic-energy scale of approximately 59.1 J. This is a value which shows the necessity for explicit arrest hardware and long stopping travel for this relatively fast system. It gives a physical measure of the speed of the motion of the carrier, not the payloads. The real coupled model takes into account the reduced masses, the finite forces and source constraints.

There is positive custody of the pallet throughout the cycle. During indexing the lift supports the pallet and before the lift grips withdraw, the carrier will grab it. The same pallet accelerates with the payload, and is subsequently used during arrest and return. Its mass is included throughout the carrier dynamics calculations and machine accounting.

The 210 mm arrest allocation sets a tighter operating limit than an acceleration-only velocity estimate. Source must provide forward current and allow a realistic braking transition to be made from acceleration conditions; regenerative current must always be limited to the capacitor voltage limit. An increased inductance will result in less current ripple, but may also have a greater current decay delay. As a result the maximum force is not sufficient to evaluate source design. This interaction is examined from both the nominal and adverse perspectives through the inductance matrix.

![Operating sequence: launch, payload + separation, active carrier arrest + return home along the rail. The payload gets separated, as the carrier/captive pallet stays attached to the host. The schematic is a functional representation of the operating cycle and is not to scale.](assets/launch_and_recovery.png){width="100%"}

## Engineering trade

The reference architecture trades simplicity and mass for per-payload commanded release and reuse of the retained mechanism. Indexed handling and fixed storage cells make it possible to use twelve payload positions with a single launch path and add sequence-control and fault-containment requirements. Retaining the magnets on the host avoids assigning motor hardware to each payload, while adding mass and inertia to the carrier. The usable operating range of the finite stator is determined by the source equivalent series resistance (ESR), voltage limit and switching limit.

The significance of the study is established through these trade-offs as they make the operating conditions and mass burden of the system explicit. Based on selected mission requirements and future prototype measurements of the dominant interfaces, the suitability of the proposed subsequent deployment architecture can then be assessed. A comprehensive engineering reference is provided for this assessment in the present computational work, not only by extrapolating from the speed of releases.

# Computational methods and model applicability

## Scientific software and reproducible artefacts

Geometry was defined in FreeCAD, using native solids from Open CASCADE, and exported to STEP, to be used for geometry exchange with others in order to create mechanical units. Tessellated copies of the original geometry were used in Blender to create scientific visualisations of the geometry. The source-face check was done using a separate mathematical implementation, but numerical calculations were done using Python, NumPy, and Magpylib. A finite-element model was generated with the program Gmsh, and the elastic model was solved with CalculiX. In the accompanying evidence, the captured results for the conductor current model and time integrator are identified. Native mission replay was done with Orekit 13.1.6, Hipparchus 4.0.3, and OpenJDK 21, and the mission results were referenced to \[20\].

In any of the scientific software domains of each tool and function will be identified by a specific task done. A rendered view describes geometric information while a solver output contains a stated boundary-value problem, and a time-step audit verifies a specific implementation. These clearly separate roles are referred to in the asset and evidence maps. The two maps show how the file path and how the file&#39;s digest SHA-256 were recorded. Both maps include the digests of the files and the file paths. These can be cross-referenced with the summary identifiers of the file paths as well as the file digests displayed at the end of the document in the figures and tables.

## Model credibility and uncertainty

If there are several techniques, the most significant comparison is when they can be compared against the specific aspect being measured. Both called source-face and cuboid models are based on the assumptions of uniform polarisation and air permeability, providing a numerical cross-check of the magnetic-field implementation. The conduction solution phenomenon is based on the same permanent-magnet field, but handles current-path effects. The shot rerun checks the governing equations, limiting logic and numerical sensitivity while retaining the same physical friction and loss allocations. The agreement between these methods reduces uncertainty in the numbers but uncertainty due to the physical system remains.

Actual Chassis analysis is applied by using the final connected solid and load patches and verifying positive mesh Jacobian and force/moment equilibrium. The geometry-difference and clearance assessment uses only the geometry mesh of a real geometry. But this evidence does not set a continuum error bound. The chassis model excludes magnets, adhesive, rollers, joints, stator supports and full host constraints.

## Physical validation boundary

The clearances are design limits not actually measured clearances. This end-frame stack is a function of rigid datums and can not include any elastic contact at the end frame. Contact-energy bounds are computed with respect to the declared rail-and-pad surrogate, while the actual tip-off response is dependent on multiple factors, including spacecraft stiffness and inertia (along with guide and friction coupling). The thermal mesh maximum is a local reading on a sharp corner and cannot be seen as a physical hotspot where temperatures are converging. Likewise, local recovery is assumed to be by diffusion between repeated shots that are separated by 450 s. The feed-capture model does not include stored energy in when there is a jam, or when there is guide play or measured restitution.

The mission families are cases created using fixed-axis J2 gravity, assuming no third body or drag effects in the atmosphere. The study also assumes a constant-inertial-force host, specific impulse of 220 s and a 72 kg of the spring host device. The two manoeuvre window policies that are reported are sampling cases, not optimised solutions. This comparison is not a conjunction safety or customer delivery confirmation. In itself, the numerical residual is not enough to prove to be accurate for a flight delivery.

Prior to giving a hardware performance rating, there are a number of measurements needed for the design which include: motor force and inductance, assembled gap and alignment, contact loads, the keeper and lock timing, the source and inverter thermal behaviour, magnetic compatibility and cycle performance. The eventual payload and host interfaces must also be subjected to the appropriate tests regarding launch restraint, vibrations, thermal-vacuum conditions, electromagnetic-compatibility, radiation and contamination. GEVS and relevant space-engineering standards provide test-planning context; citation alone does not qualify the hardware \[13\].

The proposed measurement proposals are entered based on the dependencies found in the present study. The static motor-force measurements should be obtained using the declared phase convention and at several position(s) of travel. Current, Bus Voltage, Payload speed, Carrier speed should be measured during the instrumented release test, as well as the separation event and duration. For carrier-arrest test: Must repeat the source state used during the launch. Any disagreement between the command and the actual state of the lock should be detected by the custody test. These measurements are used to validate the prototype, the computational reference is used to derive expected trends and operating range.

# Conclusion and future development

## Conclusion

The Gen5 design is an integrated computational reference for commanded electromagnetic CubeSat deployment. It has two fixed six-cell banks with guided positive pushers, a vertically indexed captive pallet and a retained moving-magnet carrier forming the payload path. Nominal compatibility of the design is achieved based on released native and STEP geometry, and 154 accepted motion and refinement checks.

Finite electromagnetic integration, an independent source-face check and an actual-current finite-element comparison support the stated motor representation. Coupling that representation to the selected source reference and actual retained moving mass yields a supported 1–3 m/s operating study. The principal 3 m/s cases pass all six nominal/adverse and inductance combinations under audited 5 µs review, including electrical limits, mechanical release and arrest within 210 mm. Actual-chassis loading predicts 0.286 mm paired closure, or 0.372 mm under the declared 1.3 multiplier.

The common-state mission comparison closes current 1–3 m/s target families while retaining ideal pretrim spring deployment as a competitive benchmark. It establishes no propellant or mass advantage over that ideal benchmark; the mechanism contribution is configured commandability.

The design has a substantial system burden: 149.557 kg represented dry CAD mass and an additional 7 kg power/control allowance. The result establishes computational feasibility within its stated cases and identifies the measurements and interfaces required for physical validation. It does not establish an installed-mass advantage or a qualified product.

## Future work and development pipeline

The present study is an integrated computational design for CubeSat storage, transfer, commanded release and carrier recovery. Physical hardware tests and performance measurements are needed to assess the design. The lab prototype phase, known as Gen6, will start by fabricating and testing the individual mechanisms and motor, and then eventually integrate those to execute an entire deployment cycle.

### Mechanism and motor test articles

The first prototype article should have 1 storage cell, pusher guided prototype, indexed lift and the captive pallet and the carrier docking locks. Feed force, feed travel, pallet position and the sequence of custody transfer will be measured by instrumentation throughout feeding, transfer and docking. Positioning repeatability will be evaluated using repeated operating cycles that will indicate presence of friction, misalignment and wear. The proposed containment and recovery sequence will be also tested during Jam, power loss and sensor disagreement conditions.

In a separate motor article, the force will be compared to the position and the magnitude of the phase current will be used for known winding and magnet configuration. For the same test setup, the resistance, inductance, terminal voltage, current and conductor temperature will all be measured. These measurements will enable the finite-field and circuit models to be correlated prior to running the integrated launcher.

### Integrated Gen6 prototype

The integrated prototype will combine the feeder, transfer pallet, launch carrier, electrical source and control system. Initial commanded-release tests will use the operating cases established by the present study. The complete sequence will include payload departure, carrier arrest, return and preparation for the next payload. Measured release speed, tip-off, contact loads, energy use and temperature will be compared with the corresponding model predictions.

The next packaging study will accommodate 1U and 3U payloads using dedicated cells and passive inserts. A reference manifest of two 1U and two 3U spacecraft will provide the first mixed-size operating case. Acceptance limits will be set against the declared payload envelope and intended host interface. The measured results will determine the prototype's operating envelope and duty cycle.

### Host integration and qualification

A selected host operator and payload interface will define the mounting pattern, launch restraints, structural loads, electrical services, command inhibits, thermal boundary and deployment constraints. The prototype will then progress through the applicable structural, vibration, thermal-vacuum, electromagnetic-compatibility and repeated-operation tests. Material selection, lubrication, contamination control and manufacturing inspection will be addressed within this hardware release.

The mission study will also examine delivery requirements that change after launch. This will quantify the value of commanded release and host manoeuvres against conventional deployment on common target states, including installed mass, power, propellant and operating time. The intended service is individually commanded delivery from an orbital-transfer or rideshare host.

### Higher-speed and later flight development

Higher release speeds require their own motor, source, stroke, payload-load and carrier-arrest design. Increasing speed raises kinetic energy with the square of velocity, so a larger speed target must be assessed together with the complete operating cycle. Longer-stroke launchers and payload-attached carrier interfaces remain separate research directions.

An ongoing research that would be useful for the future would be the study of release velocities at kilometre per second range and delivery on the moon. These developments would involve studying the initial orbit, the transfer trajectory, response of the host, the payload survivability during transfer, energy storage and guidance and lunar capture. A flight demonstration would follow measured prototype correlation, qualification and acceptance of the specific host/payload interface.

Any completed computational study serves as the reference for subsequent development of hardware, and the stages serve to preserve this. The measurements or interface evidence for each stage is generated during that stage for use in the subsequent stage.

\appendix

# Numerical and CAD evidence trail

## Controlled source map

The information about the source data and local copies of values reported in this study are described in the evidence map, which is identified in the accompanying evidence register, EVIDENCE_MAP.json. The information of figure origin and file hash is stored within ASSET_MAP.json. The connected-chassis BREP starts with &#8220;d4b53d520c1bc&#8221;, with the controlled mechanical source being marked by &#8220;e1179e886282&#8221;. The principal shot production source identifier starts with \`560088cb2a05\` and the &#34;frozen&#34; output starts with \`176f0e325089\`. There are machine-readable records, with full digests, maintained for traceability and verification.

| Evidence family | Primary current record |
|:--|:--|
| Mechanical configuration | `FINAL_CAD_MANIFEST.json` and `MECHANICAL_CAPTURE.md` |
| Accepted motion | `MOTION_VERIFICATION.json` |
| Native mass, CG and inertia | `MASS_CG_INERTIA_SUMMARY.json` |
| Finite force and source-face comparison | `FINITE_MOTOR.json`, `SURFACE_CHARGE_CHECK.json` |
| Actual conductor-current force | `CURRENT_FIELD_FORCE.json` |
| Source-coupled shots | `COUPLED_SHOT.json` |
| Shot time-step audit | `COUPLED_SHOT_REVIEW.json` and `.md` |
| Actual chassis elasticity | `CHASSIS_ACTUAL_REVIEW.md` and captured solve |
| Transfer command logic | `TRANSFER_INTERLOCKS.json` |

: Summary of the categories of evidence currently available, including paths to the files, with respect to the Gen5 engineering package.

## Reproduction sequence

First the file digests and chosen configuration identifier must be checked to start reproduction. Then the eight acquired states are used to recreate or audit the native CAD model. Part count, pallet count, Connected-solid status and interface results are compared to the configuration manifest. The mass ledger must also be checked prior to running the force, source and shot calculations. The six principal 3 m/s cases are rerun at a 5 µs time step, with results being compared to declared energy, event and voltage checks, and current. Structure reproduction takes the captured BREP, load patches, mesh and constraint definitions.

The report will be built using build_report.py, running from the python script, with Pandoc and XeLatex to generate PDF output and a native Word style file for the DOCX output. These build commands will create the academic artifacts, and in addition, the engineering package captures science runtime files and source records are needed for numerical regeneration.

# Development history

## Development of the evaluated configuration

From the initial electromagnetic sizing and packaging concepts the design evolved to a combined storage, transfer, launch and recovery mechanism. Evaluated finite winding and magnet geometry, CAD-created retained mass, declared electrical source and active carrier arrest. Previous estimates based on periodic models are listed as previous configurations and primarily retained in the engineering archive instead of as the present operating rating.

The final architecture includes both fixed banks, positively driven guided pushers, a vertically indexed captive pallet and a retained carrier. Forekeepers are opened, before payload departure, with passive cams. The powered-return and motor-arrest system then returns the carrier for the next cycle. The data presented numerically and graphically in this document are for this configuration.

# Gen6 prototype and scaling requirements

## Prototype measurement plan

To achieve one of a 1U/3U prototype, the goal is to establish one or more repeatable custody paths first, then evaluating the complete payload manifest. Some of the most important measurements will be of pusher force and travel, the position and orientation of the pallet, the engagement of the locks, the keeper opening position, the payload and carrier velocities, the phase current, the terminal end voltage, and local temperatures. It is also important that for each result obtained, the load mass, contact envelope and source state and measurement uncertainty are registered to guarantee traceability and facilitate comparison of test cycles.

| Prototype activity | Observable | Computational quantity addressed |
|:--|:--|:--|
| Static motor mapping | Force versus current and travel | Finite force coefficient and phase convention |
| Conductor/source characterization | Resistance, inductance and ESR | Current dynamics, ripple and voltage feasibility |
| Pallet transfer cycling | Pose, force and lock engagement | Custody and tolerance assumptions |
| Instrumented release/arrest | Payload/carrier speed and stop position | Unilateral release and active arrest |
| Repeated duty-cycle run | Component temperatures and recharge state | Thermal and operational schedule |

: The proposed validation activities and testing needs for the Gen6 development stage.

## Scaling criteria

At a higher release speed, the payload energy increases with the square of speed and requires greater acceleration or longer travel to get up to speed. Higher speed also changes source current, voltage, braking distance and the consequences of a failed release. A proposed change in scale will then have to take into account the full operating cycle, as well as well-defined host-system boundaries. This will require more evidence for the chosen hardware, such as how much it fits with various payloads, time frame schedule, and environmental conditions.

# Bibliography {.unnumbered}

1. JAXA, *JEM Payload Accommodation Handbook*, Vol. 8, Small Satellite Deployment Interface Control Document, via UNOOSA KiboCUBE.
2. California Polytechnic State University, *CubeSat Design Specification*, Rev. 14.1, 2022.
3. C. Foster et al., “Constellation phasing with differential drag on Planet Labs satellites,” *Journal of Spacecraft and Rockets*, vol. 55, no. 2, 2018.
4. Y. Zhao, H. Yue, X. Mu, X. Yang and F. Yang, “Design and analysis of a new deployer for the in-orbit release of multiple stacked CubeSats,” *Remote Sensing*, vol. 14, no. 17, art. 4205, 2022, doi:10.3390/rs14174205.
5. Y. Zhao et al., “Simulation analysis and experimental verification of the transport characteristics of a high-volume CubeSat storage device,” *Aerospace*, vol. 12, no. 6, art. 466, 2025, doi:10.3390/aerospace12060466.
6. H. Feng, Y. Yang and Y. Wu, “Design and reachable domain analysis of on-orbit electromagnetic launcher for CubeSats,” *International Journal of Aerospace Engineering*, art. 3000765, 2025, doi:10.1155/ijae/3000765.
7. K. Halbach, “Design of permanent multipole magnets with oriented rare earth cobalt material,” *Nuclear Instruments and Methods*, vol. 169, pp. 1–10, 1980.
8. H. Yamaguchi and M. Morishita, “End effects of Halbach field magnet-type linear motor,” *Electrical Engineering in Japan*, vol. 216, no. 4, art. e23450, 2023, doi:10.1002/eej.23450. Selected passages of the Japanese original were examined: *IEEJ Transactions on Industry Applications*, vol. 143, no. 8, pp. 570–578, 2023, doi:10.1541/ieejias.143.570.
9. D. A. Vallado, *Fundamentals of Astrodynamics and Applications*, 4th ed. Microcosm Press, 2013.
10. Eaton, *TV Supercapacitors: Cylindrical Cells*, manufacturer data sheet; captured source `eaton_tv.pdf` in the engineering package.
11. Infineon Technologies, *IRFP4668PbF Power MOSFET*, manufacturer data sheet; captured source `irfp4668.pdf`.
12. Texas Instruments, *UCC21520 Isolated Dual-Channel Gate Driver*, manufacturer data sheet; captured source `ucc21520.pdf`.
13. NASA, *General Environmental Verification Standard*, GSFC-STD-7000A, 2013.
14. FAULHABER, *Series 3242 BX4 Brushless DC-Servomotors* and *Series 32GPT Planetary Gearheads*, manufacturer data sheets; catalog references for feeder and lift sizing.
15. FreeCAD Project, *FreeCAD*, scientific and engineering software; native solid modelling and STEP exchange, software version retained in the captured runtime records.
16. M. Ortner and L. G. Coliado Bandeira, “Magpylib: A free Python package for magnetic field computation,” *SoftwareX*, vol. 11, art. 100466, 2020, doi:10.1016/j.softx.2020.100466.
17. C. Geuzaine and J.-F. Remacle, “Gmsh: A 3-D finite element mesh generator with built-in pre- and post-processing facilities,” *International Journal for Numerical Methods in Engineering*, vol. 79, no. 11, pp. 1309–1331, 2009, doi:10.1002/nme.2579.
18. G. Dhondt and K. Wittig, *CalculiX*, finite-element analysis software and user documentation; version 2.23 for the reported actual-chassis solve.
19. Blender Foundation, *Blender*, rendering software; native-geometry visualization, software version retained in render provenance.

20. Orekit Project and Hipparchus Project, *Orekit 13.1.6* and *Hipparchus 4.0.3*, orbital dynamics and numerical libraries; captured Java runtime and JAR hashes in `mission/provenance/SOFTWARE_LOCK.json`.

21. VOLLEY project, *Matched-load chassis static cross-check*, 27 October 2026; matched-load bare-chassis supplement and source-pinned native-result audit summary, `evidence/ansys/ACR1_STATIC_CROSSCHECK.json`.
