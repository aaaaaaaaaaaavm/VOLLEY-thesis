-- Resolve the report's local evidence links within its self-contained repository.
-- Exact source/export identities are held in REPORT_ISSUE.json and artifact manifests.
function RawBlock(el)
  if FORMAT=='docx' and el.format=='tex' and el.text:match('\\clearpage') then
    return pandoc.RawBlock('openxml','<w:p><w:r><w:br w:type="page"/></w:r></w:p>')
  end
end
local short_figures={"Host manoeuvre and relative release", "Integrated deployment assembly", "Motor force and reaction", "Guided-feed subassembly", "Pallet handoff and carrier locks", "Payload at the source level", "Four-stage payload transfer", "Finite motor force coefficients", "Commanded launch and carrier arrest", "Principal shot energy account", "Launch-ready carrier docking", "Chassis mesh and paired closure", "Matched-load ANSYS closure field", "Matched mission resource comparison", "Launch, departure, arrest and return"}
local short_tables={"Abbreviations and notation", "Objectives, methods and evidence", "Reference mechanism definition", "Six-case principal timestep audit", "CalculiX chassis closure", "Cross-solver closure comparison", "Mass boundaries", "Power and control mass allowance", "Rigid datum-stack sensitivity", "Conductor thermal budgets", "Payload compliance-energy bounds", "Matched-state mission candidates", "Computational results", "Numerical and CAD evidence trail", "Prototype measurement programme"}
local figure_number=0
local table_number=0
local function caption_prefix(caption,label)
  if #caption.long>0 and caption.long[1].content then
    table.insert(caption.long[1].content,1,pandoc.Str(label..':'))
    table.insert(caption.long[1].content,2,pandoc.Space())
  end
end
function Figure(el)
  figure_number=figure_number+1
  if FORMAT=='docx' then caption_prefix(el.caption,'Figure '..figure_number)
  elseif FORMAT=='latex' then el.caption.short=pandoc.Inlines({pandoc.Str(short_figures[figure_number] or '')}) end
  return el
end
function Table(el)
  table_number=table_number+1
  if FORMAT=='docx' then caption_prefix(el.caption,'Table '..table_number)
  elseif FORMAT=='latex' then el.caption.short=pandoc.Inlines({pandoc.Str(short_tables[table_number] or '')}) end
  return el
end
