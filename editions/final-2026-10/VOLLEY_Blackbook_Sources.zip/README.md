# VOLLEY blackbook sources

**VOLLEY: Design and Computational Evaluation of a Commanded Electromagnetic CubeSat Deployment Mechanism**

Adityavardhan Mishra and Pratham Chawla · Mechanical Engineering, Symbiosis Institute of Technology, Pune · October 2026

The source archive contains the text, native mathematical source, layout, figures and captured figure evidence for the 64-page report distributed alongside this archive. The report PDF is the fixed reading copy; the editable Word document includes native equations, tables and refreshable indexes.

## Build

Install Python 3.12, Pandoc, XeLaTeX with the packages named in `current/academic/layout/blackbook-header.tex`, Liberation fonts, Times New Roman or a suitable Word font, and the pinned Python dependencies. Run from this extracted directory:

```bash
python -m pip install -r requirements-documents.txt
python current/academic/build_report.py
python cache_docx_indexes.py --source-root current
```

Outputs are written to `current/academic/GEN5_FINAL_YEAR_REPORT.pdf` and `.docx`. Font and tool versions can affect pagination and binary identity. The distributed originals retain their separate checksums. Word index caches follow the companion PDF; refresh fields after editing or repagination. The source JSON preserves the document syntax tree, while the Markdown file is the builder input.

`SOURCE_MANIFEST.json` identifies every packaged input. All assets are local; a sibling repository or remote storage account is not required. Broader engineering inputs, native CAD and solver results are distributed in the thesis repository's `current/` directory. The thesis's current presentation is a separate 31-slide document issue with its own sources and manifest.
